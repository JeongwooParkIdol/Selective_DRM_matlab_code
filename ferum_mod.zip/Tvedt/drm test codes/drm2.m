%input moment of gumble distribution;
mu0=1;
mu1=5;
mu2=26;
mu3=1.411437e+002;
mu4=8.032209e+002;
mu5=4.8136663e+003;
mu6=3.052381033905024e+004;
mu7=2.057540211546609e+005;

A=[mu1 -mu0;
    mu2 -mu1];
    
B=[mu2 mu3];

X=inv(A)*B';
y=[1 -X(1,1) X(2,1)];
r=roots(y);

x1=r(2,1)
x2=r(1,1)

% three interpolation points
w1=(mu1-x2)/(x1-x2);
w2=(mu1-x1)/(x2-x1);
w=w1+w2

k=2;

% y=1-x1^2*x2/20
y1=inline('1-0.25*x1^2','x1');
y2=inline('1-1.25*x2','x2');
y3=-21/4;

% y=-exp(x1-7)-x2+10
%y1=inline('5-exp(x1-7)','x1');
%y2=inline('10-exp(-2)-x2','x2');
%y3=5-exp(-2);

h1=w1*y1(x1)^k+w2*y1(x2)^k;
h2=w1*y2(x1)^k+w2*y2(x2)^k;

mk=h1+h2-y3^k