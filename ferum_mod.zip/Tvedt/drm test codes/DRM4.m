%input moment of gumble distribution;
mu0=1;
mu1=5;
mu2=26;
mu3=1.411437e+002;
mu4=8.032209e+002;
mu5=4.8136663e+003;
mu6=3.052381033905024e+004;
mu7=2.057540211546609e+005;

A=[mu3 -mu2 mu1 -mu0;
    mu4 -mu3 mu2 -mu1;
    mu5 -mu4 mu3 -mu2;
    mu6 -mu5 mu4 -mu3];

B=[mu4 mu5 mu6 mu7];

X=inv(A)*B';
y=[1 -X(1,1) X(2,1) -X(3,1) X(4,1)];
r=roots(y);

x1=r(4,1)
x2=r(3,1)
x3=r(2,1)
x4=r(1,1)


% four interpolation points
w1=(mu3-(x2+x3+x4)*mu2+(x2*x3+x2*x4+x4*x3)*mu1-x2*x3*x4)/((x1-x2)*(x1-x3)*(x1-x4))
w2=(mu3-(x1+x3+x4)*mu2+(x1*x3+x1*x4+x4*x3)*mu1-x1*x3*x4)/((x2-x1)*(x2-x3)*(x2-x4))
w3=(mu3-(x2+x1+x4)*mu2+(x2*x1+x2*x4+x4*x1)*mu1-x2*x1*x4)/((x3-x2)*(x3-x1)*(x3-x4))
w4=(mu3-(x2+x3+x1)*mu2+(x2*x3+x2*x1+x1*x3)*mu1-x2*x3*x1)/((x4-x2)*(x4-x3)*(x4-x1))

k=2;

% y=1-x1^2*x2/20
y1=inline('1-0.25*x1^2','x1');
y2=inline('1-1.25*x2','x2');
y3=-21/4;

% y=-exp(x1-7)-x2+10
%y1=inline('5-exp(x1-7)','x1');
%y2=inline('10-exp(-2)-x2','x2');
%y3=5-exp(-2);

h1=w1*y1(x1)^k+w2*y1(x2)^k+w3*y1(x3)^k+w4*y1(x4)^k;
h2=w1*y2(x1)^k+w2*y2(x2)^k+w3*y2(x3)^k+w4*y2(x4)^k;

mk=h1+h2-y3^k