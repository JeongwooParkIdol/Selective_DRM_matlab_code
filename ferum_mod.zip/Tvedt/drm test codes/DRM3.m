%input moment of gumble distribution(mu=5, st=1);
%mu0=1;
%mu1=5;
%mu2=26;
%mu3=1.411436942312812e+002;
%mu4=8.032208958728896e+002;
%mu5=4.813666306870269e+003;
%mu6=3.052381033905024e+004;
%mu7=2.057540211546609e+005;

%input moment of normal distribution(mu=5, st=1);
mu0=1;
mu1=0;
mu2=0.25;
mu3=0;
mu4=3*0.5^4;
mu5=0;
%mu6=3.052381033905024e+004;
%mu7=2.057540211546609e+005;

%input moment of lognormal distribution(mu=2, st=1);
%mu0=1.0;
%mu1=0;
%mu2=1.0000;
%mu3=1.6257;
%mu4=8.0387;
%mu5=40.6947;

m1=5;
m2=5;

A=[mu2 -mu1 mu0;
    mu3 -mu2 mu1;
    mu4 -mu3 mu2];
    
B=[mu3 mu4 mu5];

X=inv(A)*B';
y=[1 -X(1,1) X(2,1) -X(3,1)];
r=roots(y);

x1=r(3,1)
x2=r(1,1)
x3=r(2,1)

x21=m2+r(1,1);
x22=m2+r(3,1);
x23=m2+r(2,1);

% three interpolation points
w1=(mu2-(x2+x3)*mu1+(x2*x3))/((x1-x2)*(x1-x3))
w2=(mu2-(x1+x3)*mu1+(x1*x3))/((x2-x1)*(x2-x3))
w3=(mu2-(x2+x1)*mu1+(x2*x1))/((x3-x2)*(x3-x1))

k=2;

% y=1-x1^2*x2/20
%y1=inline('1-0.25*x1^2','x1');
%y2=inline('1-1.25*x2','x2');
%y3=-21/4;

% y=1-(x1+x2-5)^2/30-(x1-x2-12)^2/120
y1=inline('1-x1^2/30-(x1-17)^2/120','x1');
y2=inline('1-x2^2/30-(x2+7)^2/120','x2');
y3=1-25/30-144/120;

%y=-exp(x1-7)-x2+10
%y1=inline('exp(x1/4)','x1');
%y2=inline('exp(x2/4)','x2');
%y3=exp(1.25);

%y=(x-8)^2-(y-3)^2
%y1=inline('(x1-8)^2-(3-3)^2','x1');
%y2=inline('(8-8)^2-(x2-3)^2','x2');
%y3=(m1-8)^2-(m2-3)^2

h1=w1*y1(x1+5)^k+w2*y1(x2+5)^k+w3*y1(x3+5)^k;
h2=w1*y2(x1+5)^k+w2*y2(x2+5)^k+w3*y2(x3+5)^k;

mk=h1+h2-y3^k