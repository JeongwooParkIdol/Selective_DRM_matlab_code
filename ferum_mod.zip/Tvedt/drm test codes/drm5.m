%input moment of gumble distribution;
mu=5;
st=0.5;

mu0=1;
mu1=0;
mu2=1*st^2;
mu3=0;
mu4=3*st^4;
mu5=0;
mu6=15*st^6;
mu7=0;
mu8=105*st^8;
mu9=0;

A=[mu4 -mu3 mu2 -mu1 mu0;
    mu5 -mu4 mu3 -mu2 mu1;
    mu6 -mu5 mu4 -mu3 mu2;
    mu7 -mu6 mu5 -mu4 mu3;
    mu8 -mu7 mu6 -mu5 mu4];

B=[mu5 mu6 mu7 mu8 mu9];

X=inv(A)*B';
y=[1 -X(1,1) X(2,1) -X(3,1) X(4,1) -X(5,1)];
r=roots(y);

x1=r(5,1);
x2=r(4,1);
x3=r(3,1);
x4=r(2,1);
x5=r(1,1);

% five interpolation points
w1=(mu4-(x2+x3+x4+x5)*mu3+(x2*x4+x2*x3+x2*x5+x3*x4+x3*x5+x4*x5)*mu2-(x2*x3*x4+x2*x4*x5+x2*x3*x5+x3*x4*x5)*mu1+x2*x3*x4*x5)/((x1-x2)*(x1-x3)*(x1-x4)*(x1-x5));
w2=(mu4-(x1+x3+x4+x5)*mu3+(x1*x4+x1*x3+x1*x5+x3*x4+x3*x5+x4*x5)*mu2-(x1*x3*x4+x1*x4*x5+x1*x3*x5+x3*x4*x5)*mu1+x1*x3*x4*x5)/((x2-x1)*(x2-x3)*(x2-x4)*(x2-x5));
w3=(mu4-(x2+x1+x4+x5)*mu3+(x2*x4+x2*x1+x2*x5+x1*x4+x1*x5+x4*x5)*mu2-(x2*x1*x4+x2*x4*x5+x2*x1*x5+x1*x4*x5)*mu1+x2*x1*x4*x5)/((x3-x2)*(x3-x1)*(x3-x4)*(x3-x5));
w4=(mu4-(x2+x3+x1+x5)*mu3+(x2*x1+x2*x3+x2*x5+x3*x1+x3*x5+x1*x5)*mu2-(x2*x3*x1+x2*x1*x5+x2*x3*x5+x3*x1*x5)*mu1+x2*x3*x1*x5)/((x4-x2)*(x4-x3)*(x4-x1)*(x4-x5));
w5=(mu4-(x2+x3+x4+x1)*mu3+(x2*x4+x2*x3+x2*x1+x3*x4+x3*x1+x4*x1)*mu2-(x2*x3*x4+x2*x4*x1+x2*x3*x1+x3*x4*x1)*mu1+x2*x3*x4*x1)/((x5-x2)*(x5-x3)*(x5-x4)*(x5-x1));



k=4;

% y=1-x1^2*x2/20
y1=inline('1-x1^2/30-1/120*(x1-17)^2','x1');
y2=inline('1-x2^2/30-1/120*(x2+7)^2','x2');
y3=1-25/30-1.2;

% y=-exp(x1-7)-x2+10
%y1=inline('5-exp(x1-7)','x1');
%y2=inline('10-exp(-2)-x2','x2');
%y3=5-exp(-2);

h1=w1*y1(x1+mu)^k+w2*y1(x2+mu)^k+w3*y1(x3+mu)^k+w4*y1(x4+mu)^k+w5*y1(x5+mu)^k;
h2=w1*y2(x1+mu)^k+w2*y2(x2+mu)^k+w3*y2(x3+mu)^k+w4*y2(x4+mu)^k+w5*y2(x5+mu)^k;

mk=h1+h2-y3^k