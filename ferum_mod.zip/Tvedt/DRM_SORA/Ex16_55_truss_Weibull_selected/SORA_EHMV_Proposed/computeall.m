function [myc,Iter_constraint] = computeall(X,Iter_constraint, Shift_X,G_value_recorded, GRAD_G, Active_set,X_ref)

ndv = 7;


for j = 1:7
    if Active_set(j) == 1
        X1 = X -  Shift_X(:,j);
        sigma = truss_analysis_55_truss(X1);
        myc(j) = abs(sigma(j)/X1(8)) - 1;
        Iter_constraint(j) = Iter_constraint(j) + 1;
    else
        G = G_value_recorded(j) ;
        for i = 1:ndv
           if  GRAD_G(i,j) > 0
               G = G + GRAD_G(i,j)*(X(i) - X_ref(i,j));
           else
               G = G + GRAD_G(i,j)*X_ref(i,j)/X(i)*(X(i) - X_ref(i,j));
           end
        end
        myc(j) =G;
    end    
    
end



end