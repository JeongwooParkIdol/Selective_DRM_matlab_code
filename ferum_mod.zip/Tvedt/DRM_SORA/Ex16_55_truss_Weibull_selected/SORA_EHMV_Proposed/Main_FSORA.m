clear all
warning off;

addpath '../Truss_analysis'

x0 = [5;2;4;1.5;2;1.5;1.5];

ncon = 7;

lb = [1;1;1;1;1;1;1]+0.5;
ub = [15;15;15;15;15;15;15];

Cov_X = [zeros(7,1)+0.1;0.05];

Distri = zeros(8,1); 
Distri(1:7) = 1; % 1 : normal distribution
Distri(8) = 16;  % 16 : Weibull distribution

Beta_input = [3 3 3 3 3 3 3];

history.x = [];
history.x1 = [];
history.x2 = [];
history.x3 = [];
history.fval = [];
history.gval = [];
history.gradc1 = [];
history.gradc2 = [];
history.gradc3 = [];


fid1 = fopen('FSORA.txt','w');
[x,fval,exitflag,output,Shift_X,history] = FSORA(x0,ncon,lb,ub,Cov_X,Distri,Beta_input, history, fid1);

fclose(fid1);
