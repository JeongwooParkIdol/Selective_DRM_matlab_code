function myc = truss_analysis_55_truss_3(x)

[sigma] = truss_analysis_55_truss(x);
X=x;
% if size(X,1) == 9
    G = abs(sigma(3)/X(8)) - 1;
% else
%     G = abs(sigma(3)/2.5E04) - 1;
% end
myc = -G;


end