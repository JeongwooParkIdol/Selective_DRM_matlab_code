function [sigma] = truss_analysis_55_truss(X)
% FE control data
numel = 55; % number of element
numnp = 26; % number of node
ndf = 3; % number of degree of freedom
nst = numnp * ndf; % total degree of freedom of the structure
% material properties : all the members have the same length
E = 20e06;
% E = X(10);
A = zeros(55,1);
A(1:5) = X(1);
A(6:10) = X(2);
A(11:15) = X(3);
A(16:25) = X(4);
A(26:35) = X(5);
A(36:45) = X(6);
A(46:55) = X(7);
% A = X(1:7);
% Iter_constraint = Iter_constraint +1;
% initialization of array
u = zeros(nst,1);
f = zeros(nst,1);
s = zeros(nst,nst);

% nodal coordinates
x = [0.0            ,  0.0            ,  150.0;   
0.0            ,  78.8509        ,  127.6031;
-74.9916       ,  24.3663        ,  127.6031;
-46.3474       ,  -63.7917       ,  127.6031;
46.3474        ,  -63.7917       ,  127.6031;
74.9916        ,  24.3663        ,  127.6031;
-74.9951       ,  103.2219       ,  78.8732 ;
74.9951        ,  103.2219       ,  78.8732 ;
121.3446       ,  -39.4272       ,  78.8732 ;
0.0            ,  -127.5892      ,  78.8732 ;
-121.3446      ,  -39.4272       ,  78.8732 ;
0.0            ,  134.1548       ,  67.1006 ;
-127.5888      ,  41.4561        ,  67.1006 ;
-78.8542       ,  -108.5335      ,  67.1006 ;
78.8542        ,  -108.5335      ,  67.1006 ;
127.5888       ,  41.4561        ,  67.1006 ;
-150.0         ,  0.0            ,  0.0     ;
-121.3525      ,  88.1678        ,  0.0     ;
-46.3525       ,  142.6585       ,  0.0     ;
46.3525        ,  142.6585       ,  0.0     ;
121.3525       ,  88.1678        ,  0.0     ;
150.0          ,  0.0            ,  0.0     ;
121.3525       ,  -88.1678       ,  0.0     ;
46.3525        ,  -142.6585      ,  0.0     ;
-46.3525       ,  -142.6585      ,  0.0     ;
-121.3525      ,  -88.1678       ,  0.0     ];
x1 = x(:,1);
x2 = x(:,2);
x3 = x(:,3);
% element connectivities
elem = [   1,         2;
   1,         3;
   1,         4;
   1,         5;
   1,         6;
   2,        12;
   3,        13;
   4,        14;
   5,        15;
   6,        16;
   3,         2;
   2,         6;
   6,         5;
   5,         4;
   4,         3;
   3,         7;
   7,         2;
   2,         8;
   8,         6;
   6,         9;
   9,         5;
   5,        10;
  10,         4;
   4,        11;
  11,         3;
  13,         7;
   7,        12;
  12,         8;
   8,        16;
  16,         9;
   9,        15;
  15,        10;
  10,        14;
  14,        11;
  11,        13;
  17,        13;
  18,        13;
  19,        12;
  12,        20;
  21,        16;
  16,        22;
  23,        15;
  15,        24;
  25,        14;
  14,        26;
  18,         7;
   7,        19;
  20,         8;
   8,        21;
  22,         9;
   9,        23;
  24,        10;
  10,        25;
  26,        11;
  11,        17];
% structural stiffness I
s = stiffness(numnp,numel,ndf,elem,E,A,x1,x2,x3);
ebc = 49:78;
% natural boundary condition
% f(6) = -1500;
% f(12) = -1000;
% if size(X,1) == 7
f(3) = -300000;
% elseif size(X,1) > 7
%     f(3) = X(8);
% end
    
% free degree of freedom
freeDof = setdiff([1:numnp*ndf]',ebc);
% displacement vector with only free degree of freedom
u = s(freeDof,freeDof)\f(freeDof);
% make the full size of displacement vector
ug = zeros(numnp*ndf,1);
ug(freeDof) = u;
% calculation the reation
f = s*ug;
% reaction = f(ebc);
% calculate the element stress 
Sigma = elementstress(E,ndf,numel,elem,ug,x1,x2,x3);
sigma(1) = max(Sigma(1:5));
sigma(2) = max(Sigma(6:10));
sigma(3) = max(Sigma(11:15));
sigma(4) = max(Sigma(16:25));
sigma(5) = max(Sigma(26:35));
sigma(6) = max(Sigma(36:45));
sigma(7) = max(Sigma(46:55));


end