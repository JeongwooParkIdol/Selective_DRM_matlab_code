
newFolder='E:\study\matlab\excersice\For_third_paper\Ex16_55_truss_Weibull_selected\PMA_DRM_5';

cd(newFolder);

Main_PMA

newFolder='E:\study\matlab\excersice\For_third_paper\Ex7_selected\Normal\DPMA_5';

cd(newFolder);

Main_DPMA

newFolder='E:\study\matlab\excersice\For_third_paper\Ex7_selected\Normal\DSORA_EHMV_Proposed';

cd(newFolder);

Main_DSORA