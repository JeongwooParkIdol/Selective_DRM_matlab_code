function [myc,Iter_constraint] = computeall(X,Iter_constraint)




for j = 1:7

        sigma = truss_analysis_55_truss(X);
        myc(j) = abs(sigma(j)/2.5E04) - 1;
        Iter_constraint(j) = Iter_constraint(j) + 1;
    
end



end