function Active_set = Check_Active_set(ncon,lambda)



Active_set = zeros(ncon,1);


for i = 1:ncon
    if lambda.ineqnonlin(i) ~= 0 
        Active_set(i) = 1;
    end
end


end