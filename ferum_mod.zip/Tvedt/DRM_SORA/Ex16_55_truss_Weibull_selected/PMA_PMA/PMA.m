function [x,fval,exitflag,output,history] = PMA(x0,lb,ub,Cov_X,Distri,Beta_input,history,ncon,fid1,Flag_IC)


xLast = [];
myf = [];
myc = [];
grad_myc = [];

ndv = size(x0,1);

% DMPFP_X= zeros(ndv+2,ncon);
% DDMPFP_X = zeros(ndv+2,ncon);
% 
% for i = 1:ncon
%     DDMPFP_X(:,i) = [x0;-1500;-1000];
% end

DMPFP_U= zeros(ndv+1,ncon);

Iter_constraint = zeros(ncon,1);
Iter_obj = 0;




fun = @objfun;
cfun = @constr;
rel_cfun = @rel_constr;


epsi = 1E-03;
% options=optimset('Display','iter-detailed','TolCon',0.001,'Tolfun',0.001,'TolX',0.001,,'Algorithm','SQP');
% options=optimset('Display','iter-detailed','TolCon',epsi,'Tolfun',epsi,'TolX',epsi);

%% first iteration k = 0
options=optimset('Display','iter-detailed','TolCon',epsi/10,'Tolfun',epsi,'TolX',epsi);
[x,fval,exitflag,output,lambda,grad,hessian]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,cfun,options);

fprintf(fid1,'x: %f %f %f %f %f %f %f, fval: %f\n',x,fval);
fprintf(fid1,'\nIteration constraints: %d %d %d %d %d %d %d\n',Iter_constraint);
fprintf(fid1,'total_constraint: %d\n',sum(Iter_constraint));
fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%% PMA
options=optimset('Display','iter-detailed','TolCon',epsi/10,'Tolfun',epsi,'TolX',epsi,'GradConstr','on');



xLast = [];
myf = [];
myc = [];


[x,fval,exitflag,output]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,rel_cfun,options);

fprintf(fid1,'x: %f %f %f %f %f %f %f, fval: %f\n',x,fval);
fprintf(fid1,'\nIteration constraints: %d %d %d %d %d %d %d\n',Iter_constraint);
fprintf(fid1,'total_constraint: %d\n',sum(Iter_constraint));
fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%% Feasible check
if Flag_IC == 1
    pfs = zeros(ncon,1);
    bts = zeros(ncon,1);
    bts_f = zeros(ncon,1);
    j=0;
    Mu = [x;2.5E04];
    for i = 1:ncon
        j=j+1
        [Pf Beta] = Feasible_check(Mu,Cov_X,i,Distri);
        pfs(i) = Pf;
        bts(i) = -norminv(Pf);
        bts_f(i) = Beta;
    end
    pft = normcdf(-Beta_input(1));



    Err = (pft - pfs)/pft ;
    fprintf(fid1,'\nfeasible check\n');
    fprintf(fid1,'Pf: %f %f %f %f %f %f %f\n',pfs);
    fprintf(fid1,'err: %f %f %f %f %f %f %f\n',Err);
    fprintf(fid1,'Beta(FORM): %f %f %f %f %f %f %f\n',bts_f);
    fprintf(fid1,'Beta(IC): %f %f %f %f %f %f %f\n',bts);
end
%% Calculate objective and constraint functions


    function [y ] = objfun(X)
        myf = truss_analysis_55_truss_area_Cal(X);
        Iter_obj = Iter_obj + 1;
        y = myf; 
    end

    function [c,ceq,gradc,gradceq] = rel_constr(x)
        if ~isequal(x,xLast)
            [myc, grad_myc,Iter_obj, Iter_constraint,history,DMPFP_U] = Estimation_Reliability(x,Iter_obj,Iter_constraint,ncon,Cov_X,Distri,Beta_input,history,DMPFP_U,fid1);
            xLast = x;
        end
        
        c = myc;
        if nargout > 2
            gradc = grad_myc(:,1:7)';
        end
        ceq = [];
        gradceq = [];

    end

    function [c,ceq] = constr(x)

        [myc,Iter_constraint] = computeall(x,Iter_constraint);       

        

        c = myc;

        ceq = [];

    end




end