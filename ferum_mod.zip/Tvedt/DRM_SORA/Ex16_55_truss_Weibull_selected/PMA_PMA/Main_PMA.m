% PMA - version 02
% analytical sensitivity analysis 
clear all
warning off;

addpath '../Truss_analysis'

x0 = [5;2;4;1.5;2;1.5;1.5];
% x0 = [0.025;0.025;0.025;0.025;0.025;0.025;0.025];
ncon = 7;

% lb = [0.001;0.001;0.001;0.001;0.001;0.001;0.001];
% ub = [0.06;0.06;0.06;0.06;0.06;0.06;0.06];

lb = [1;1;1;1;1;1;1]+0.5;
ub = [15;15;15;15;15;15;15];

Beta_input = [3 3 3 3 3 3 3];

Cov_X = [zeros(7,1)+0.1;0.05];
Distri = zeros(8,1); 
Distri(1:7) = 1; % 1 : normal distribution
Distri(8) = 16;  % 16 : Weibull distribution

history.x = [];
history.x1 = [];
history.x2 = [];
history.x3 = [];
history.x4 = [];
history.x5 = [];
history.x6 = [];
history.x7 = [];

history.fval = [];
history.gval = [];
history.gval1 = [];
history.gval2 = [];
history.gval3 = [];
history.gval4 = [];
history.gval5 = [];
history.gval6 = [];
history.gval7 = [];
history.gradc1 = [];
history.gradc2 = [];
history.gradc3 = [];
history.gradc4 = [];
history.gradc5 = [];
history.gradc6 = [];
history.gradc7 = [];
history.gradc1 = [];
history.gradc2 = [];
history.gradc3 = [];
history.gradc4 = [];
history.gradc5 = [];
history.gradc6 = [];
history.gradc7 = [];

fid1 = fopen('PMA.txt','w');
Flag_IC = 1;
[x,fval,exitflag,output,history] = PMA(x0,lb,ub,Cov_X,Distri,Beta_input,history,ncon,fid1,Flag_IC);

fclose(fid1);