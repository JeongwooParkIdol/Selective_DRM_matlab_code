function [G_value Grad_G_rt_X  U Iter_constraint history VBeta Flag_ECA]=SubProblem(DMPFP_U,Aver_X,Sig_X,Index_G,Beta_input,VBeta,Flag_ECA ,ndv,Distri,Iter_constraint,history)


Epislion = 0.0001;
Epsilon1 = 0.0175;
No_Intp = 5;

Delta_min = 1e-10;
Delta_ratio = 0.0005;
Iter = 0;
Sign = 1;

% U = zeros(ndv,1);

%     U = (DDMPFP_X(:,Index_G) - Aver_X )./Sig_X;
    U = DMPFP_U(:,Index_G);
%     U = zeros(ndv  ,1);
    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);

Flag_MPP = 0;
delta = 0;
Grad_G_prev = zeros(ndv,3);
U_prev = zeros(ndv,3);
G_prev = zeros(1,3);
G_old = 10;

Flag_DRM = 1;
while 1
    
    [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);    

    U_prev = [U_prev(:,2) U_prev(:,3) U];
    G_prev = [G_prev(2) G_prev(3) G];
    Grad_G_prev = [Grad_G_prev(:,2) Grad_G_prev(:,3) Grad_G];
    
    if norm(U) <= 1E-15 
        norm_U = 1E-15;
    else
        norm_U = norm(U);
    end
    if norm(Grad_G) <= 1E-15
        norm_Grad_G = 1E-15;
    else
        norm_Grad_G = norm(Grad_G);
    end
    
    if Iter == 0
       if norm_Grad_G/sqrt(ndv)*0.5 <= 1
           check_G = G + norm_Grad_G/sqrt(ndv)*0.5 ;
       else
           check_G = G + 0.5;
       end
       if check_G <= 0 && Flag_ECA(Index_G) == 0
           Flag_DRM = 0;
           break
       else 
           Flag_ECA(Index_G) = 1;
       end
        
    end
    Flag_ECA(Index_G) = 1;
    KKT_Cond = abs( Sign*U'/norm_U * (-Grad_G)/norm_Grad_G -1 );
    
%     Rel_G = abs(G - G_old)/G_old;
    
    if Flag_MPP == 1
        break
    end
    
    if KKT_Cond <= Epislion && Iter >= 2        
%     if KKT_Cond <= Epislion      
        break
    end
    

    
    
    if Iter >= 100
        disp('Fail to find iMPP')
    end
   
    [U G  delta Flag_MPP Iter_constraint] = U_update(U, delta, Epsilon1,  Iter, Aver_X, Sig_X, Distri, Flag_MPP,  Index_G, Beta_input, Grad_G, Iter_constraint);
    
    Iter = Iter + 1;        
end


if Flag_DRM == 1
    [VBeta Iter_constraint]= Calculate_VBeta_DRM(Aver_X,Sig_X,Distri,Index_G,Beta_input,VBeta,Grad_G,U,G, No_Intp,ndv,Iter_constraint);

    U = VBeta(Index_G)*U/norm(U);

    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);

    [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);
end

[x J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);
    
G_value = G;

Grad_G_rt_X = J_u_x*Grad_G;
end

function [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint)

X = Aver_X + U.*Sig_X;


Delta = zeros(ndv,1);
for i = 1:ndv
    Delta(i) = abs(U(i)) * Delta_ratio;
    if Delta(i) <= Delta_min 
        Delta(i) = Delta_min;
    end
end

U_plus_del = U;
Grad_G = zeros(ndv,1);
for i = 1:ndv
    U_plus_del(i) = U(i) + Delta(i);

    [G_forward Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U_plus_del,Iter_constraint);
    
    Grad_G(i) = (G_forward - G) / Delta(i);
    
    U_plus_del(i) = U(i);    
end   

end


function [U G  delta Flag_MPP Iter_constraint] = U_update(U, delta, Epsilon,  Iter, Aver_X, Sig_X, Distri , Flag_MPP,  Index_G, Beta_input, Grad_G, Iter_constraint)

U_old = U;
delta_old = delta;

if norm(Grad_G) <= 1E-10
    norm_Grad_G = 1E-10;
else 
    norm_Grad_G = norm(Grad_G);
end

U_cur = Beta_input(Index_G) * Grad_G/norm_Grad_G;

if norm(U_old) <= 1E-10
    norm_U_old = 1E-10;
else
    norm_U_old = norm(U_old);
end

if norm(U_cur) <= 1E-10
    norm_U_cur = 1E-10;
else
    norm_U_cur = norm(U_cur);
end
    

delta = acos( U_cur'*U_old/(norm_U_old*norm_U_cur) );

if delta <= Epsilon
    Flag_MPP = 1;
    U = U_cur;
    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);
    return
end

if Iter < 1
    U = U_cur;
    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);
else
    if delta*1.2 < delta_old
        U = U_cur;
        [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);
    else
        [U_cur G Iter_constraint] = arc_max(U_old,Grad_G, Aver_X, Sig_X,Distri, Index_G,  delta, Beta_input, Iter_constraint);
        if norm(U_cur) <= 1E-10
            norm_U_cur = 1E-10;
        else
            norm_U_cur = norm(U_cur);
        end
        delta = acos( U_cur'*U_old/(norm_U_old*norm_U_cur) );
        U = U_cur;                
        if delta <= Epsilon
            Flag_MPP = 1;

            return
        end        
    end
end
        
        
  

    
end

function [U G Iter_constraint] = arc_max(U_old,Grad_G, Aver_X, Sig_X, Distri,Index_G,  delta, Beta_input, Iter_constraint)


Bt = Beta_input(Index_G);


Y = @(delt) -Cal_G_arc(delt, Aver_X, Sig_X, Distri,Index_G, Bt,  U_old, Grad_G, Iter_constraint);

if norm(U_old) <= 1E-10
    norm_U_old = 1E-10;
else
    norm_U_old = norm(U_old);
end

if norm(Grad_G) <= 1E-10
    norm_Grad_G = 1E-10;
else
    norm_Grad_G = norm(Grad_G);
end

Gamma = acos( U_old'*Grad_G/ ( norm_U_old * norm_Grad_G) );

epsi = 1E-03;

options = optimset('TolX',epsi,'TolFun',epsi,'Display','off');


[delt_opt, G ,exitflag,output] = fminunc(Y,delta,options);
G = -G;

Iter_constraint(Index_G) = Iter_constraint(Index_G) + output.funcCount;


U = Bt/sin(Gamma) * (sin(Gamma - delt_opt) * U_old/norm_U_old + sin(delt_opt) * Grad_G/norm_Grad_G );

end

function Y = Cal_G_arc(delt, Aver_X, Sig_X, Distri,Index_G, Bt,  U_old, Grad_G, Iter_constraint)

if norm(U_old) <= 1E-10
    norm_U_old = 1E-10;
else
    norm_U_old = norm(U_old);
end

if norm(Grad_G) <= 1E-10
    norm_Grad_G = 1E-10;
else
    norm_Grad_G = norm(Grad_G);
end

Gamma = acos( U_old'*Grad_G/ ( norm_U_old * norm_Grad_G) );

U = Bt/sin(Gamma) * (sin(Gamma - delt) * U_old/norm_U_old + sin(delt) * Grad_G/norm_Grad_G );

[Y Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);


end