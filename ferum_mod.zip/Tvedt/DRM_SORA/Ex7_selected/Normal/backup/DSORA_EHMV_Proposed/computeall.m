function [myf, myc,Iter_obj, Iter_constraint] = computeall(X,Iter_obj,Iter_constraint, Shift_X,G_value_recorded, GRAD_G, Active_set,X_ref)

myf = -(X(1)+X(2)-10)^2/30 - (X(1)-X(2)+10)^2/120;
ndv = 2;
% grad_myf = [1, 1];
% Iter_obj = Iter_obj + 1;
% Iter_obj = Iter_obj + 2;
if Active_set(1) == 1
    X1 = X -  Shift_X(:,1);
    myc(1) = -(X1(1)^2 * X1(2)/20 - 1);
    Iter_constraint(1) = Iter_constraint(1) + 1;
else
    G = G_value_recorded(1) ;
    for i = 1:ndv
       if  GRAD_G(i,1) > 0
           G = G + GRAD_G(i,1)*(X(i) - X_ref(i,1));
       else
           G = G + GRAD_G(i,1)*X_ref(i,1)/X(i)*(X(i) - X_ref(i,1));
       end
    end
    myc(1) =G;
end

if Active_set(2) == 1
    X2 = X -  Shift_X(:,2);
    Y1 = 0.9063*X2(1) + 0.4226*X2(2) - 6;
    Y2 = -0.4226*X2(1) + 0.9063*X2(2);
    myc(2) = -( 1 - Y1^2 -Y1^3 +0.6*Y1^4 + Y2);
    Iter_constraint(2) = Iter_constraint(2) + 1;
else
    G = G_value_recorded(2) ;
    for i = 1:ndv
       if  GRAD_G(i,2) > 0
           G = G + GRAD_G(i,2)*(X(i) - X_ref(i,2));
       else
           G = G + GRAD_G(i,2)*X_ref(i,2)/X(i)*(X(i) - X_ref(i,2));
       end
    end
    myc(2) =G;
end

if Active_set(3) == 1
    X3 = X -  Shift_X(:,3);
    myc(3) = -(80/(X3(1)^2 + 8*X3(2) + 5) - 1);

    Iter_constraint(3) = Iter_constraint(3) + 1;
else
    G = G_value_recorded(3) ;
    for i = 1:ndv
       if  GRAD_G(i,3) > 0
           G = G + GRAD_G(i,3)*(X(i) - X_ref(i,3));
       else
           G = G + GRAD_G(i,3)*X_ref(i,3)/X(i)*(X(i) - X_ref(i,3));
       end
    end
    myc(3) =G;
end




end