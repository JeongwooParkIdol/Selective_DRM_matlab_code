function [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint)

sum_U = U'*U;
Beta = sqrt(sum_U);

% X = Aver_X + U.*Sig_X;

[X J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);

Y1 = 0.9063*X(1) + 0.4226*X(2) - 6;
Y2 = -0.4226*X(1) + 0.9063*X(2);

if Index_G == 1
    G = X(1)^2 * X(2)/20 - 1;
elseif Index_G == 2
    G = 1 - Y1^2 -Y1^3 +0.6*Y1^4 + Y2;
%     G = - G;
elseif Index_G == 3
    G = 80/(X(1)^2 + 8*X(2) + 5) - 1;
end
G=-G;
Iter_constraint(Index_G) = Iter_constraint(Index_G) + 1;

end