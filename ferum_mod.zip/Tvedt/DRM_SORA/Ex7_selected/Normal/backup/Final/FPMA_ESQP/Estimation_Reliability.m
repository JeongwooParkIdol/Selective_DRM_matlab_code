function [myc, grad_myc,  Iter_obj, Iter_constraint,history,DMPFP_U, DMPFP_r] = Estimation_Reliability(x,Iter_obj,Iter_constraint,ncon,Sig_X,Distri,Beta_input,history,DMPFP_U,DMPFP_r,fid1)



Aver_X = x;
ndv = size(Aver_X,1);
Iter_old = zeros(ncon,1);



for Index_G = 1:ncon
    
   

    Iter_old(Index_G) = Iter_constraint(Index_G);
    [G_value Grad_G_rt_X  U Iter_constraint history DMPFP_r]=SubProblem(DMPFP_r,Aver_X,Sig_X,Index_G,Beta_input,ndv,Distri,Iter_constraint,history);
    
    Iter_old(Index_G) = Iter_constraint(Index_G) - Iter_old(Index_G);
    
    DMPFP_U(:,Index_G) =  U ;
    
    myc(Index_G) = -G_value; 

    grad_myc(Index_G,:) = -Grad_G_rt_X';
    
end
fprintf(fid1,'\nIteration constraints for RA: %d %d %d\n',Iter_old(1), Iter_old(2), Iter_old(3));

    
end
    