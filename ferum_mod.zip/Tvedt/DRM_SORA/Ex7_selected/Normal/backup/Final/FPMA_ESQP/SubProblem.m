function [G_value Grad_G_rt_X  U Iter_constraint history DMPFP_r]=SubProblem(DMPFP_r,Aver_X,Sig_X,Index_G,Beta_input,ndv,Distri,Iter_constraint,history)


Delta_min = 1e-10;
Delta_ratio = 0.0005;

r = DMPFP_r(:,Index_G);

ndv = size(Aver_X,1);

Iter = 0;

%% Initialize r
if r == zeros(ndv,1)
    U = zeros(ndv,1);
    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);
    [Iter_constraint Grad_G]= Gradient_G_U(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);
    
    InitialU = -Beta_input(Index_G)*Grad_G/norm(Grad_G);
    
    r= Transform_u_to_r(InitialU,ndv);
    
    Iter  = Iter + 1;
    

end

if Index_G == 1
    M = history.M1;
elseif Index_G == 2
    M = history.M2;
else 
    M = history.M3;
end

fun = @ simulopt;

lm = [];
lb = zeros(1,1) - inf;
ub = zeros(1,1) + inf;
options.algo_method        = 'quasi-Newton';
options.algo_globalization = 'line-search';
% options.algo_descent = 'Wolfe';
tolopt = 1E-03;
options.tol(1)  = tolopt;  % tolerance on the gradient of the Lagrangian
options.tol(2)  = tolopt;  % tolerance on the feasibility
options.tol(3)  = tolopt;  % tolerance on the complementarity
options.miter   = 1000;       % max iterations
options.msimul  = 1000;       % max simulations
options.fout    = 1;          % print file identifier
options.verbose = 0;          % verbosity level


[r,lm,info] = sqplab (fun,r,lm,[],[],options,M);




if Index_G == 1
    history.M1 = info.M;
elseif Index_G == 2
    history.M2 = info.M;
else 
    history.M3 = info.M;
end

U = Transform_r_to_u(r,ndv,Beta_input,Index_G);
    
G_value = G;

DMPFP_r(:,Index_G) = r;

[Iter_constraint Grad_G]= Gradient_G_U(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);

[x J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);

Grad_G_rt_X = J_u_x*Grad_G;

function [outdic,f,ci,ce,cs,g,ai,ae] = simulopt (indic,r,lm)


    ci = [];
    ai = [];
    ce = [];
    ae = [];
    outdic = [];
    f = [];   cs = []; g = [];  
    
    u1 = [];
    u2 =[];
    G1 = [];
    X1 = [];
    X2 = [];
    Y1 = [];
    Y2 =[];
    f = [];
    rr = [];


    if indic == 1 % 1: the simulator can do whatever

    elseif indic == 2 % 2: compute f, ci, and ce
        U = zeros(ndv,1);
        U(1) = Beta_input(Index_G)*cos(r);
        U(2) = Beta_input(Index_G)*sin(r);
        [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);
        f = G;
        ce = [];
        ci=  [];



    elseif indic == 3 % 3: compute g, ai, and ae

        [Iter_constraint Grad_G_r]= Gradient_G_r(Index_G, Aver_X, Sig_X, Distri,Beta_input,Delta_min, Delta_ratio, ndv, r, G, Iter_constraint);
        g = Grad_G_r;
        
        ae = [];         
        ae = sparse(ae);
        ai = [];
        ai = sparse(ai);        
    elseif indic == 4; % 4: compute f, ci, ce, g, ai, and ae
        U = Transform_r_to_u(r,ndv,Beta_input,Index_G);
        [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);
        syms rr
        u1 = 1.645*cos(rr);
        u2 = 1.645*sin(rr);
        X1 = Sig_X(1)*u1 + Aver_X(1);
        X2 = Sig_X(2)*u2 + Aver_X(2);
        if Index_G == 1
            G1 = X1^2 * X2/20 - 1;
        elseif Index_G == 2
            Y1 = 0.9063*X1 + 0.4226*X2 - 6;
            Y2 = -0.4226*X1 + 0.9063*X2;
            G1 = 1 - Y1^2 -Y1^3 +0.6*Y1^4 + Y2;
        else
            G1 = 80/(X1^2 + 8*X2 + 5) - 1;
        end
        g1 = subs(diff(G1,rr),r);
        
        
        f = G;
        ce = [];
        ci=  [];
        [Iter_constraint Grad_G_r]= Gradient_G_r(Index_G, Aver_X, Sig_X, Distri,Beta_input,Delta_min, Delta_ratio, ndv, r, G, Iter_constraint);
        g = Grad_G_r;

        ae = [];         
        ae = sparse(ae);
        ai = [];
        ai = sparse(ai);    

    elseif indic == 5



    else


    end

end


end