function [U J_u_r]= Transform_r_to_u(r,ndv,Beta_input,Index_G)

U = zeros(ndv,1);
Bt = Beta_input(Index_G);
U(1) = Bt*cos(r(1));
U(2) = Bt*sin(r(1));

J_u_r = [-Bt*sin(r(1)) Bt*cos(r(1))];

end