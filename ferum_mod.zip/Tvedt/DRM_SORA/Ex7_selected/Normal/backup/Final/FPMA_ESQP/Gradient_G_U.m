function [Iter_constraint Grad_G]= Gradient_G_U(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint)

    X = Aver_X + U.*Sig_X;


    Delta = zeros(ndv,1);
    for i = 1:ndv
        Delta(i) = abs(U(i)) * Delta_ratio;
        if Delta(i) <= Delta_min 
            Delta(i) = Delta_min;
        end
    end

    U_plus_del = U;
    Grad_G = zeros(ndv,1);
    for i = 1:ndv
        U_plus_del(i) = U(i) + Delta(i);

        [G_forward Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U_plus_del,Iter_constraint);

        Grad_G(i) = (G_forward - G) / Delta(i);

        U_plus_del(i) = U(i);    
    end   

end