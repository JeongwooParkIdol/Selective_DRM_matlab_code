function [Iter_constraint Grad_G_r]= Gradient_G_r(Index_G, Aver_X, Sig_X, Distri,Beta_input,Delta_min, Delta_ratio, ndv, r, G, Iter_constraint)

    Delta = zeros(ndv-1,1);
    for i = 1:ndv-1
        Delta(i) = abs(r(i)) * Delta_ratio;
        if Delta(i) <= Delta_min 
            Delta(i) = Delta_min;
        end
    end

    r_plus_del = r;
    Grad_G_r = zeros(ndv-1,1);
    for i = 1:ndv-1
        r_plus_del(i) = r(i) + Delta(i);
        
        [U J_u_r]= Transform_r_to_u(r_plus_del,ndv,Beta_input,Index_G);

        [G_forward Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);

        Grad_G_r(i) = (G_forward - G) / Delta(i);

        r_plus_del(i) = r(i);    
    end   

end