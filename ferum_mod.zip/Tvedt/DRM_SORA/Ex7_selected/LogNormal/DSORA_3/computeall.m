function [myf, myc,Iter_obj, Iter_constraint] = computeall(X,Iter_obj,Iter_constraint, Shift_X)

myf = -(X(1)+X(2)-10)^2/30 - (X(1)-X(2)+10)^2/120;

% grad_myf = [1, 1];
% Iter_obj = Iter_obj + 1;
% Iter_obj = Iter_obj + 2;

X1 = X -  Shift_X(:,1);
myc(1) = -(X1(1)^2 * X1(2)/20 - 1);
Iter_constraint(1) = Iter_constraint(1) + 1;


X2 = X -  Shift_X(:,2);
Y1 = 0.9063*X2(1) + 0.4226*X2(2) - 6;
Y2 = -0.4226*X2(1) + 0.9063*X2(2);
myc(2) = -( 1 - Y1^2 -Y1^3 +0.6*Y1^4 + Y2);

Iter_constraint(2) = Iter_constraint(2) + 1;

X3 = X -  Shift_X(:,3);
myc(3) = -(80/(X3(1)^2 + 8*X3(2) + 5) - 1);

Iter_constraint(3) = Iter_constraint(3) + 1;

end