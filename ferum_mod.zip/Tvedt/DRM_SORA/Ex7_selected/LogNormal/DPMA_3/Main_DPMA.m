% PMA - version 02
% analytical sensitivity analysis 
clear all
warning off;


x0 = [4;3];
% x0 = [3.10;2.09];
ncon = 3;
ndv = size(x0,1);

lb = [0;0];
ub = [10;10];

Sig_X = [0.3;0.3];
Distri = zeros(ndv,1);
Distri(1:2) = 1;

Beta_input = zeros(ncon,1) + 1.645;
VBeta = Beta_input;

history.x = [];
history.x1 = [];
history.x2 = [];
history.x3 = [];
history.fval = [];
history.gval = [];
history.gradc1 = [];
history.gradc2 = [];
history.gradc3 = [];

fid1 = fopen('DPMA.txt','w');
[x,fval,exitflag,output,history] = DPMA(x0,lb,ub,Sig_X,Distri,Beta_input,VBeta,history,ncon,fid1);

fclose(fid1);