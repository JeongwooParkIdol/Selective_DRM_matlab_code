function [x,fval,exitflag,output,history] = DPMA(x0,lb,ub,Sig_X,Distri,Beta_input,VBeta,history,ncon,fid1)


xLast = [];
myf = [];
myc = [];
grad_myc = [];

ndv = size(x0,1);

DMPFP_U= zeros(ndv,ncon);





Iter_constraint = zeros(ncon,1);
Iter_obj = 0;



epsi = 1E-04;


rel_cfun = @rel_constr;
rel_fun = @rel_objfun;

% options=optimset('Display','iter-detailed','TolCon',0.001,'Tolfun',0.001,'TolX',0.001,,'Algorithm','SQP');
options=optimset('Display','iter-detailed','TolCon',epsi,'Tolfun',epsi,'TolX',epsi,'GradConstr','on','Algorithm','SQP');

%%PMA

xLast = [];
myf = [];
myc = [];


[x,fval,exitflag,output]=fmincon(rel_fun , x0 ,[] ,[],[],[],lb,ub,rel_cfun,options);

fprintf(fid1,'x: %f %f, fval: %f\n',x(1),x(2),fval);
fprintf(fid1,'\nIteration constraints: %d %d %d\n',Iter_constraint(1), Iter_constraint(2), Iter_constraint(3));
fprintf(fid1,'total_constraint: %d\n',Iter_constraint(1)+Iter_constraint(2)+ Iter_constraint(3));
fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%% Feasible check
pfs = zeros(2,1);
bts = zeros(2,1);
bts_f = zeros(2,1);
j=0;
for i = 1:2
    j=j+1
    [Pf Beta] = Feasible_check(x,Sig_X,i,Distri);
    pfs(i) = Pf;
    bts(i) = -norminv(Pf);
    bts_f(i) = Beta;
end
pft = normcdf(-1.645);

[pf bt] = MCS(ndv,ncon,  x, Sig_X);

Err = (pft - pfs)/pft ;

fprintf(fid1,'\nfeasible check\n');
fprintf(fid1,'Pf: %f %f %f\n',pf);
fprintf(fid1,'Beta(MCS): %f %f %f\n',bt);
fprintf(fid1,'err: %f %f\n',Err);
fprintf(fid1,'Beta(FORM): %f %f\n',bts_f);
fprintf(fid1,'Beta(SORM): %f %f\n',bts);
%% Calculate objective and constraint functions


    function [y ] = rel_objfun(x)
            myf = -(x(1)+x(2)-10)^2/30 - (x(1)-x(2)+10)^2/120;
            Iter_obj = Iter_obj + 1;
              
        y = myf;

    end

    function [c,ceq,gradc,gradceq] = rel_constr(x)
        if ~isequal(x,xLast)
            [myc, grad_myc, Iter_obj, Iter_constraint,history,DMPFP_U,VBeta] = Estimation_Reliability(x,Iter_obj,Iter_constraint,ncon,Sig_X,Distri,Beta_input,VBeta,history,DMPFP_U,fid1);
            xLast = x;
        end
        
        if nargout > 2
            gradc = grad_myc';
        end
        c = myc;
        ceq = [];
        gradceq = [];

    end

    

end