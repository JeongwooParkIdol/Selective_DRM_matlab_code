% PMA - version 02
% analytical sensitivity analysis 
clear all
warning off;


x0 = [0.1;4];
% x0 = [5.196892;0.740530];
% x0 = [5.197;0.741];
% x0 = [3.10;2.09];
ncon = 4;
ndv = size(x0,1);

lb = [0.1;0.1];
ub = [6.0;6.0];

Cov_X = [0.05;0.05;0.15;0.15;0.10;0.50;0.12];
Distri = zeros(ndv,1);
Distri(1:2) = 1;
Distri(3:4) = 2;
Distri(5) = 1;
Distri(6) = 2;
Distri(7) = 16;

Beta_input = [2;2;3;3];

history.x = [];
history.x1 = [];
history.x2 = [];
history.x3 = [];
history.fval = [];
history.gval = [];
history.gradc1 = [];
history.gradc2 = [];
history.gradc3 = [];

fid1 = fopen('FPMA.txt','w');
[x,fval,exitflag,output,history] = FPMA(x0,lb,ub,Cov_X,Distri,Beta_input,history,ncon,fid1);

fclose(fid1);