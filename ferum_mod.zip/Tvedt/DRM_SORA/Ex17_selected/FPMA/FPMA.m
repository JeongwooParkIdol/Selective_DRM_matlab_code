function [x,fval,exitflag,output,history] = FPMA(x0,lb,ub,Cov_X,Distri,Beta_input,history,ncon,fid1)


xLast = [];
myf = [];
myc = [];
grad_myc = [];

ndv = size(x0,1);

DMPFP_U= zeros(ndv+5,ncon);





Iter_constraint = zeros(ncon,1);
Iter_obj = 0;



epsi = 1E-03;




rel_cfun = @rel_constr;
rel_fun = @rel_objfun;

% options=optimset('Display','iter-detailed','TolCon',0.001,'Tolfun',0.001,'TolX',0.001,,'Algorithm','SQP');

myf = [];
myc = [];

cfun = @constr;
options=optimset('Display','iter-detailed','TolCon',epsi/10,'Tolfun',epsi,'TolX',epsi,'Algorithm','SQP');
[x0,fval,exitflag,output]=fmincon(rel_fun , x0 ,[] ,[],[],[],lb,ub,cfun,options);

fprintf(fid1,'x: %f %f, fval: %f\n',x0(1),x0(2),fval);
fprintf(fid1,'\nIteration constraints: %d %d %d\n',Iter_constraint(1), Iter_constraint(2), Iter_constraint(3));
fprintf(fid1,'total_constraint: %d\n',Iter_constraint(1)+Iter_constraint(2)+ Iter_constraint(3));
fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%%PMA

xLast = [];
myf = [];
myc = [];

options=optimset('Display','iter-detailed','TolCon',epsi/10,'Tolfun',epsi,'TolX',epsi,'GradConstr','on','Algorithm','SQP');
[x,fval,exitflag,output]=fmincon(rel_fun , x0 ,[] ,[],[],[],lb,ub,rel_cfun,options);

fprintf(fid1,'x: %f %f, fval: %f\n',x(1),x(2),fval);
fprintf(fid1,'\nIteration constraints: %d %d %d\n',Iter_constraint(1), Iter_constraint(2), Iter_constraint(3));
fprintf(fid1,'total_constraint: %d\n',Iter_constraint(1)+Iter_constraint(2)+ Iter_constraint(3));
fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%% Feasible check
pfs = zeros(2,1);
bts = zeros(2,1);
bts_f = zeros(2,1);
j=0;
x = [x ; 0.4;0.5;30000;1.46E10;50];
for i = [1 3]
    j=j+1
    [Pf Beta] = Feasible_check(x,Cov_X,i,Distri);
    pfs(j) = Pf;
    bts(j) = -norminv(Pf);
    bts_f(j) = Beta;
end
% pft = normcdf(-1.645);

% [pf bt] = MCS(ndv,ncon,  x, Sig_X);

% Err = (pft - pfs)/pft ;

fprintf(fid1,'\nfeasible check\n');
fprintf(fid1,'Pf: %f %f  \n',pfs);
% fprintf(fid1,'Beta(MCS): %f %f %f\n',bts);
% fprintf(fid1,'err: %f %f\n',Err);
fprintf(fid1,'Beta(FORM): %f %f \n',bts_f);
fprintf(fid1,'Beta(SORM): %f %f \n',bts);
%% Calculate objective and constraint functions


    function [y ] = rel_objfun(x)
            myf = x(1)*x(2);
            Iter_obj = Iter_obj + 1;
              
        y = myf;

    end

    function [c,ceq,gradc,gradceq] = rel_constr(x)
        if ~isequal(x,xLast)
            [myc, grad_myc, Iter_obj, Iter_constraint,history,DMPFP_U] = Estimation_Reliability(x,Iter_obj,Iter_constraint,ncon,Cov_X,Distri,Beta_input,history,DMPFP_U,fid1);
            xLast = x;
        end
        
        if nargout > 2
            gradc = grad_myc';
        end
        c = myc;
        ceq = [];
        gradceq = [];

    end

    function [c,ceq] = constr(x)
        x = [x ; 0.4;0.5;30000;1.46E10;50];
        [myc, Iter_constraint] = computeall(x,Iter_constraint);
        
        c = myc;

        ceq = [];

    end

    

end