function [myc, grad_myc,VBeta,  Iter_obj, Iter_constraint,history,DMPFP_U] = Estimation_Reliability(x,Iter_obj,Iter_constraint,ncon,Cov_X,Distri,VBeta,Beta_input,history,DMPFP_U,fid1)



Aver_X = [x ; 0.4;0.5;30000;1.46E10;50];
Sig_X = Aver_X.*Cov_X;
ndv = size(Aver_X,1);
Iter_old = zeros(ncon,1);



for Index_G = 1:ncon
    
   

    Iter_old(Index_G) = Iter_constraint(Index_G);
    [G_value Grad_G_rt_X  U VBeta Iter_constraint history]=SubProblem(DMPFP_U,Aver_X,Sig_X,Index_G,VBeta,Beta_input,ndv,Distri,Iter_constraint,history);
    
    Iter_old(Index_G) = Iter_constraint(Index_G) - Iter_old(Index_G);
    
    DMPFP_U(:,Index_G) =  U ;
    
    myc(Index_G) = -G_value; 

    grad_myc(Index_G,:) = -Grad_G_rt_X(1:2)';
    
end
fprintf(fid1,'\nIteration constraints for RA: %d %d %d\n',Iter_old(1), Iter_old(2), Iter_old(3));

    
end
    