function [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint)

sum_U = U'*U;
Beta = sqrt(sum_U);

L = 30.0;
N0 = 2E06;
Del0 = 0.15;

[X J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);

if Index_G == 1
    G = X(4) - 0.3*X(5)*X(1)^3*X(2)/L^2;
elseif Index_G == 2
    G = N0*6*X(3)*L/(X(1)*X(2)^2) - X(6);
elseif Index_G == 3
    G = 4*X(4)*L^3/(X(5)*X(1)*X(2)^3) - Del0;
elseif Index_G == 4
    G = 6*X(4)*L/(X(1)*X(2)^2) - X(7);
end

G = -G;
    

Iter_constraint(Index_G) = Iter_constraint(Index_G) + 1;

end