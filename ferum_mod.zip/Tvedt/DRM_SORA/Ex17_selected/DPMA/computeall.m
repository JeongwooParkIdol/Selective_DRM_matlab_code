function [myc, Iter_constraint] = computeall(X,Iter_constraint)

L = 30.0;
N0 = 2E06;
Del0 = 0.15;

myc(1) = X(4) - 0.3*X(5)*X(1)^3*X(2)/L^2;
Iter_constraint(1) = Iter_constraint(1) + 1;


myc(2) = N0*6*X(3)*L/(X(1)*X(2)^2) - X(6);
Iter_constraint(2) = Iter_constraint(2) + 1;


myc(3) = 4*X(4)*L^3/(X(5)*X(1)*X(2)^3) - Del0;
Iter_constraint(3) = Iter_constraint(3) + 1;

myc(4) = 6*X(4)*L/(X(1)*X(2)^2) - X(7);
Iter_constraint(4) = Iter_constraint(4) + 1;

end