function [x,fval,exitflag,output,Shift_X,history] = DSORA(x0,ncon,lb,ub,Cov_X,Distri,VBeta,Beta_input, history, fid1)



myf = [];
myc = [];

Active_set = ones(ncon,1);

ndv = size(x0,1);
epsi = 1E-03;
Iter_constraint = zeros(ncon,1);
Iter_obj = 0;

nrv = 7;

X_ref = zeros(ndv,ncon);


DMPFP_U = zeros(nrv,ncon);
GRAD_G = zeros(ndv,ncon);
Shift_X = zeros(nrv,ncon);

fun = @objfun;
cfun = @constr;

% options=optimset('Display','iter-detailed');
options=optimset('Display','iter-detailed','TolCon',epsi/10,'Tolfun',epsi,'TolX',epsi,'Algorithm','SQP');

G_value_recorded = zeros(ncon,1);

%% first iteration k = 0
[x,fval,exitflag,output,lambda,grad,hessian]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,cfun,options);

fprintf(fid1,'\nx0: %f %f\n',x0(1),x0(2));
fprintf(fid1,'shift_vector\n');
fprintf(fid1,'x: %f %f, fval: %f\n',x(1),x(2),fval);
fprintf(fid1,'FE_constraint: %d %d %d %d\n',Iter_constraint);

%% 

[Active_set Total_Grad_G] = Check_Active_set(ndv,ncon,history);

% x= x0;

Del_obj = epsi;

Del_obj1 = Del_obj*10;

Obj_old = 10;

Iter = 0;

% Ctmin = 0.003;


Sum_FE_RA = 0;
while Del_obj1 >= Del_obj 
    Aver_X = [x ; 0.4;0.5;30000;1.46E10;50];
    Sig_X = Aver_X.*Cov_X;
    Iter_constraint_old = Iter_constraint;
    
    for Index_G = 1:ncon
              
        if Active_set(Index_G) == 1
            [G_value U Grad_G_rt_X VBeta Iter_constraint history]=SubProblem(DMPFP_U,Aver_X,Sig_X,Distri,Index_G,VBeta,Beta_input,nrv,Iter_constraint,history);
            G_value_recorded(Index_G) = G_value;
            GRAD_G(:,Index_G) = Grad_G_rt_X(1:2,1);
            
            [Xs J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);
        
            DMPFP_U(:,Index_G) = U;

            Shift_X(:,Index_G) = Aver_X - Xs;      
        else
            G_value_recorded(Index_G) = history.gval(Index_G,end);
            GRAD_G(:,Index_G) = Total_Grad_G(:,Index_G);
            X_ref(:,Index_G) = history.x(:,end);
        end

       
        
    end
    
    Iter = Iter + 1;
    
    Iter_constraint_RA = Iter_constraint  - Iter_constraint_old;
    
    Sum_FE_RA = Sum_FE_RA + sum(Iter_constraint_RA);
    myf = [];
    myc = [];
    
    x0 = Aver_X(1:ndv,1);
    Iter_constraint_old = Iter_constraint;
    [x,fval,exitflag,output]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,cfun,options);
    Iter_constraint_FE = Iter_constraint - Iter_constraint_old;
    
    [Active_set Total_Grad_G] = Check_Active_set(ndv,ncon,history);
    
    Del_obj1 = abs((fval-Obj_old)/Obj_old);
    Del_obj2 = abs((fval-Obj_old));
    Del_obj1 = min([Del_obj1,Del_obj2]);
    Obj_old = fval;   
    
    fprintf(fid1,'\nx0: %f %f\n',x0(1),x0(2));
    fprintf(fid1,'x: %f %f, fval: %f\n',x(1),x(2),fval);
    fprintf(fid1,'G_feasibility: %f %f %f %f\n',G_value_recorded);
    fprintf(fid1,'Iter_RA: %d %d %d %d\n',Iter_constraint_RA);
    fprintf(fid1,'Iter_FE: %d %d %d %d\n',Iter_constraint_FE);
    
end

fprintf(fid1,'\nIteration constraints: %d %d %d %d\n',Iter_constraint);
fprintf(fid1,'total function call for reliability analysis: %d\n',Sum_FE_RA);
fprintf(fid1,'total_constraint: %d\n',sum(Iter_constraint));

fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%% Feasibility check
pfs = zeros(2,1);
bts = zeros(2,1);
bts_f = zeros(2,1);
j=0;
x = [x ; 0.4;0.5;30000;1.46E10;50];
for i = [1 3]
    j=j+1
    [Pf Beta] = Feasible_check(x,Cov_X,i,Distri);
    pfs(j) = Pf;
    bts(j) = -norminv(Pf);
    bts_f(j) = Beta;
end


fprintf(fid1,'\nfeasible check\n');
fprintf(fid1,'Pf: %f %f \n',pfs);
fprintf(fid1,'Beta(FORM): %f %f \n',bts_f);
fprintf(fid1,'Beta(SORM): %f %f \n',bts);
%% Calculate objective and constraint functions
    function [y] = objfun(X)

        myf = X(1)*X(2);
        Iter_obj = Iter_obj + 1;

        y = myf;      

    end

    function [c,ceq] = constr(x)
        x = [x ; 0.4;0.5;30000;1.46E10;50];
        [myc,Iter_constraint] = computeall(x,Iter_constraint, Shift_X,G_value_recorded, GRAD_G, Active_set,X_ref);
        
        history.x = [history.x x(1:2,1)];
        
        history.gval = [history.gval myc'];
        

        c = myc;

        ceq = [];

    end

    
    
    
end

