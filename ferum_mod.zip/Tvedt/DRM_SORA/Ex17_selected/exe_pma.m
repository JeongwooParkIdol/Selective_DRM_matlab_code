
newFolder='E:\study\matlab\excersice\For_third_paper\Ex17\FPMA';

cd(newFolder);

Main_FPMA
% 
% 
newFolder='E:\study\matlab\excersice\For_third_paper\Ex17\DPMA';

cd(newFolder);

Main_DPMA
% 
newFolder='E:\study\matlab\excersice\For_third_paper\Ex17\SORA_EHMV_Proposed_DRM';

cd(newFolder);

Main_DSORA

% newFolder='E:\study\matlab\excersice\For_third_paper\Ex7\Normal\DSORA_5';
% 
% cd(newFolder);
% 
% Main_DSORA

% newFolder='E:\study\matlab\excersice\For_third_paper\Ex7\Normal\DPMA_3';
% 
% cd(newFolder);
% 
% Main_DPMA
% 
% newFolder='E:\study\matlab\excersice\For_third_paper\Ex7\Normal\DPMA_5';
% 
% cd(newFolder);
% 
% Main_DPMA