function [Pf Beta]= Feasible_check(mu,Cov_X,Index_G,Distri)

% U = DMPFP_U(:,Index_G);

sigma = mu.*Cov_X;

% [Xs J_u_x] = Transform_u_to_x(U,mu,sigma,Distri);

ndv = size(mu,1);
for i = 1:ndv
    probdata.marg(i,:) =  [ Distri(i)  mu(i)   sigma(i)   mu(i)  0 0 0 0 0];
end
 

probdata.correlation = eye(ndv,ndv);

probdata.parameter = distribution_parameter(probdata.marg);
gfundata(1).evaluator = 'basic';
gfundata(1).type = 'expression'; 
gfundata(1).parameter = 'no';

% FORM analysis options
analysisopt.ig_max    = 100;
analysisopt.il_max    = 5;
analysisopt.i_max = 100; % Maximum number of iterations allowed in the search algorithm
analysisopt.e1 = 0.001; % Tolerance on how close design point is to limit-state surface
analysisopt.e2 = 0.001; % Tolerance on how accurately the gradient points towards
                        % the origin
analysisopt.step_code = 0; % 0: step size by Armijo rule
                            % otherwise: given value is the step size
analysisopt.Recorded_u = 1; % 0: u-vector not recorded at all iterations
                            % 1: u-vector recorded at all iterations
analysisopt.Recorded_x = 1; % 0: x-vector not recorded at all iterations
                            % 1: x-vector recorded at all iterations
analysisopt.grad_flag = 'ffd';
analysisopt.ffdpara = 1000;

% IC analysis options
analysisopt.rand_generator = 1; % 0: default rand matlab function
                                % 1: Mersenne Twister (to be preferred)
analysisopt.num_sim = 1e7; % Number of samples

analysisopt.stdv_sim  = 1;

analysisopt.target_cov = 0.01;
analysisopt.lowRAM = 0; % 1: memory savings allowed
                        % 0: no memory savings allowed

femodel = 0;
randomfield.mesh = 0;

% performance function

% IC : dspt, CMCS : origin
analysisopt.sim_point = 'dspt';
% the nubmer of sampling points
% analysisopt.num_sim   = 1e04;

if Index_G == 1
    gfundata(1).expression = '-(x(4) - 0.3*x(5)*x(1)^3*x(2)/30.0^2)';
elseif Index_G == 2
    gfundata(1).expression = '-(2E06*6*x(3)*30.0/(x(1)*x(2)^2) - x(6))';
elseif Index_G == 3
    gfundata(1).expression = '-(4*x(4)*30^3/(x(5)*x(1)*x(2)^3) - 0.15)';
elseif Index_G == 4
    gfundata(1).expression = '-(6*x(4)*30/(x(1)*x(2)^2) - x(7))';
end
    
[formresults] = form(1,probdata,analysisopt,gfundata,femodel,randomfield);
analysisopt.sim_point =formresults.dsptu;

% analysisopt.sim_point =DMPFP_U(:,Index_G);
[simulationresults] = simulation(1,probdata,analysisopt,gfundata,femodel,randomfield);

Pf= simulationresults.pf;

% sormresults = sorm_curvature_fitting(1,formresults,probdata,analysisopt,gfundata,femodel,randomfield);

% Pf = sormresults.pf2;

% Pf = formresults.pf1;  
Beta = norm(formresults.dsptu);
% Beta = 3;
end
    