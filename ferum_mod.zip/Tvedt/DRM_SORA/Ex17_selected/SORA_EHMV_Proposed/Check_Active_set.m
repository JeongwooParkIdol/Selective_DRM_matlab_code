function [Active_set Total_Grad_G]= Check_Active_set(ndv,ncon,history)

epsi_f = 0.5;

Active_set = zeros(ncon,1);

% Calculate derivatives from history
Total_Grad_G = zeros(ndv,ncon);
for i = 1:ndv
    Grad_G = ( history.gval(:,end-ndv+i) - history.gval(:,end-ndv) )/ (history.x(i,end-ndv+i) - history.x(i,end-ndv));
    Total_Grad_G(i,:) = Grad_G';
    
end

% Identification of active and epsi - active constraint
for i = 1:ncon
    G_check = history.gval(i,end) + epsi_f*norm(Total_Grad_G(:,i))/sqrt(7);
    if G_check > 0 
        Active_set(i) = 1;
    end
end


end