function [myc,Iter_constraint] = computeall(X,Iter_constraint, Shift_X,G_value_recorded, GRAD_G, Active_set,X_ref)


ndv = 2;

L = 30.0;
N0 = 2E06;
Del0 = 0.15;

for j = 1:4
    if Active_set(j) == 1
        X1 = X -  Shift_X(:,j);
        if j == 1
            myc(j) = X1(4) - 0.3*X1(5)*X1(1)^3*X1(2)/L^2;
        elseif j == 2
            myc(j) = N0*6*X1(3)*L/(X1(1)*X1(2)^2) - X1(6);
        elseif j == 3
            myc(j) = 4*X1(4)*L^3/(X1(5)*X1(1)*X1(2)^3) - Del0;
        elseif j == 4
            myc(j) = 6*X1(4)*L/(X1(1)*X1(2)^2) - X1(7);  
        end
        Iter_constraint(j) = Iter_constraint(j) + 1;
    else
        G = G_value_recorded(j) ;
        for i = 1:ndv
           if  GRAD_G(i,j) > 0
               G = G + GRAD_G(i,j)*(X(i) - X_ref(i,j));
           else
               G = G + GRAD_G(i,j)*X_ref(i,j)/X(i)*(X(i) - X_ref(i,j));
           end
        end
        myc(j) =G;
    end    
    
end



end