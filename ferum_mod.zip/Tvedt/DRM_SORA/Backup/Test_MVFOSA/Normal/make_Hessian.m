function [B kappa analy_kappa] = make_Hessian(Grad_Total, X_Total,Aver_X)
%         Aver_X = [2;1];
% Aver_X = [3.8;2];
% Aver_X = [1;2];
Sig_X = [0.8;0.8];
n = size(Grad_Total,2);
ndv = size(Grad_Total,1);

n_grad = n;

B = zeros(ndv);

syms u1 u2
u = [u1;u2];
x = u.*Sig_X + Aver_X;
G = -(exp(0.8*x(1)-1.2) + exp(0.7*x(2) - 0.6) - 5)/10;
Anal_Hess_G = hessian(G);

for ii = 1:n_grad-1
    sk = X_Total(:,ii+1) - X_Total(:,ii);                
    yk = Grad_Total(:,ii+1) -Grad_Total(:,ii) ;
    rk = yk - B*sk;
    
    if abs(rk'*sk) > 1E-06*norm(sk)*norm(rk)
        B_temp = rk*rk'/(rk'*sk);
    else
        B_temp = zeros(ndv); 
    end
    
    B = B + B_temp;
    grad_G = Grad_Total(:,ii+1);
    kappa(ii) = cal_curvature(B,  grad_G);
    
    Hess_G = subs(subs(Anal_Hess_G,u1,X_Total(1,ii+1)),u2,X_Total(2,ii+1));
    analy_kappa(ii) = cal_curvature(Hess_G, grad_G);
end

Hess_G = subs(subs(Anal_Hess_G,u1,0),u2,0);
kappa_0 = cal_curvature(Hess_G, Grad_Total(:,1));



        
end