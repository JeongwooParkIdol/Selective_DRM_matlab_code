function kappa = cal_curvature(hess_G,  grad_G)

alpha = -grad_G / norm(grad_G);
marg_dim = 2;
% Compute the rotation matrix
R1 = gram_schmidt(alpha');

A = R1*hess_G*R1' / norm(grad_G);

[eigenvectors,D] = eig(A([1:(marg_dim-1)],[1:(marg_dim-1)]));
   
for i=1:marg_dim-1
    kappa(i) = D(i,i);
end

% kappa = det(hess_G);


end