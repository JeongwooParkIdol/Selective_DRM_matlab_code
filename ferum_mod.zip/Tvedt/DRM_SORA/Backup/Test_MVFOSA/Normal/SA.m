function [Pf_MVFOSA Pf_MVFORM]= SA(Aver_X,Sig_X, Distri, g, grad_g, ndv)


y=0;


fun = @(t) dCGF_Y(t, Aver_X,Sig_X,Distri,g,grad_g, ndv);
x0=0;
ts = fzero(fun,x0);

[Ky ddKy] = CGF_Y(ts, Aver_X,Sig_X,Distri,g,grad_g, ndv);

w = sign(ts)*sqrt(2* (ts*y - Ky) );

v= ts*sqrt(ddKy);

Pf_MVFOSA = normcdf(w) + normpdf(w)*(1/w-1/v);
       

sigma_Y = 0;

for i =1:ndv
    sigma_Y = sigma_Y + (grad_g(i)*Sig_X(i))^2;
end

sigma_Y = sqrt(sigma_Y);

Pf_MVFORM = normcdf( (y-g)/sigma_Y );





end

function [Ky ddKy] = CGF_Y(t, Aver_X,Sig_X,Distri,g,grad_g, ndv)

    Ky = (g - grad_g'*Aver_X)*t;
    
    Vec_Kx = zeros(ndv,1);
    
    for i = 1:ndv
        t1 = grad_g(i)*t;
        [Kx dKx ddKx] = CGF_x(Aver_X, Sig_X, Distri,t1, i);
        Vec_Kx(i) = Kx;        
    end
    
    Ky = Ky + sum(Vec_Kx);
    
    ddKy = 0;
    for i = 1:ndv
       t1 = grad_g(i)*t; 
       [Kx dKx ddKx] = CGF_x(Aver_X, Sig_X, Distri,t1, i); 
       ddKy = ddKy + grad_g(i)^2 * ddKx;
        
    end
    
   

end

function dKy = dCGF_Y(t, Aver_X,Sig_X,Distri,g,grad_g, ndv)

    dKy = g - grad_g'*Aver_X;
    
    Vec_dKx = zeros(ndv,1);
    
    for i = 1:ndv
        t1 = grad_g(i)*t;
        [Kx dKx ddKx] = CGF_x(Aver_X, Sig_X, Distri,t1, i);
        Vec_dKx(i) = dKx;        
    end
    
    dKy = dKy + grad_g'*Vec_dKx;

end



function [Kx dKx ddKx] = CGF_x(Aver_X, Sig_X,Distri, t, i)

    if Distri(i) == 1
        mu = Aver_X(i);
        sigma = Sig_X(i);
        Kx = mu*t + 1/2*sigma^2 * t^2;
        dKx = mu + sigma^2 * t;    
        ddKx = sigma^2;
    end
end