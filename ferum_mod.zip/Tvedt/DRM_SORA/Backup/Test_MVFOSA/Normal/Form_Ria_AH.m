% function [formresults sormresults B1 history II] = Form_Ria_AH(mu, sigma, Index_G,history,XMPP,II)
clear all
disp('Normal')
Flag_plot = 0;
Flag_MCS = 0;
Aver_X = [5.5;3];
Sig_X = [0.3;0.3];
Distri(1:2) = 1;
ndv = 2;

for i = 1:ndv
    probdata.marg(i,:) =  [ Distri(i)  Aver_X(i)   Sig_X(i)   Aver_X(i)  0 0 0 0 0];
end

% probdata.marg(1,:) =  [ 1  mu(1)   sigma(1)   mu(1)   0 0 0 0 0];
% probdata.marg(2,:) =  [ 1  mu(2)   sigma(2)   mu(2)  0 0 0 0 0];
% probdata.marg(1,:) =  [ 1  mu(1)   sigma(1)   MPP(1)  0 0 0 0 0];
% probdata.marg(2,:) =  [ 1  mu(2)   sigma(2)   MPP(2)  0 0 0 0 0];

probdata.correlation = eye(ndv);

probdata.parameter = distribution_parameter(probdata.marg);
gfundata(1).evaluator = 'basic';
gfundata(1).type = 'expression'; 
gfundata(1).parameter = 'no';

% gfundata(1).thetag = [ mu(1) mu(2) ];

% FORM analysis options
analysisopt.ig_max    = 100;
analysisopt.il_max    = 5;
analysisopt.i_max = 100; % Maximum number of iterations allowed in the search algorithm
analysisopt.e1 = 0.001; % Tolerance on how close design point is to limit-state surface
analysisopt.e2 = 0.001; % Tolerance on how accurately the gradient points towards
                        % the origin
analysisopt.step_code = 0; % 0: step size by Armijo rule
                            % otherwise: given value is the step size
analysisopt.Recorded_u = 1; % 0: u-vector not recorded at all iterations
                            % 1: u-vector recorded at all iterations
analysisopt.Recorded_x = 1; % 0: x-vector not recorded at all iterations
                            % 1: x-vector recorded at all iterations
analysisopt.grad_flag = 'ffd';
analysisopt.ffdpara = 1000;

% IC analysis options
analysisopt.rand_generator = 1; % 0: default rand matlab function
                                % 1: Mersenne Twister (to be preferred)
analysisopt.num_sim = 1e8; % Number of samples

analysisopt.stdv_sim  = 1;

analysisopt.target_cov = 0.001;
analysisopt.lowRAM = 0; % 1: memory savings allowed
                        % 0: no memory savings allowed

femodel = 0;
randomfield.mesh = 0;

% performance function

% IC : dspt, CMCS : origin
analysisopt.sim_point = 'dspt';
% the nubmer of sampling points
% analysisopt.num_sim   = 1e04;

% gfundata(1).expression = 'x(1)^3 + x(1)^2*x(2) + x(2)^3 - 18';
gfundata(1).expression = '80/(x(1)^2+8*x(2)+5)-1';
% gfundata(1).expression = '-exp(x(1)-7)-x(2)+10';
    
[formresults] = form(1,probdata,analysisopt,gfundata,femodel,randomfield)
Grad_Total = formresults.grad_G;
X_Total = formresults.u;
% [hess_G kappa analy_kappa] = make_Hessian(Grad_Total, X_Total,Aver_X);
% sormresults = sorm_curvature_fitting(1,formresults,probdata,analysisopt,gfundata,femodel,randomfield);
% sormresults_ASORM = sorm_curvature_fitting_ASORM(1,hess_G,formresults,probdata,analysisopt,gfundata,femodel,randomfield);
[Pf_MVFOSA Pf_MVFORM] = SA(Aver_X,Sig_X, Distri, formresults.gfcn(1), formresults.grad_g(:,1), ndv)



if Flag_plot == 1
    syms u1 u2
    u = [u1;u2];
    x = u.*Sig_X + Aver_X;
    G = -(exp(0.8*x(1)-1.2) + exp(0.7*x(2) - 0.6) - 5)/10;
    ax = [-0.5 2.5 -1 2];
    % ax = [-0.5 5 -0.5 5]*10;
    U = formresults.dsptu;

    dG_du1_FORM = formresults.grad_G(:,end);
    Taylor_FORM =  dG_du1_FORM(1)*(u1-U(1)) + dG_du1_FORM(2)*(u2-U(2));
    g1 = ezplot(Taylor_FORM,ax);
    XY1 = get(g1,'contourMatrix');

    U1 = [u1 - U(1);u2 - U(2)];
    Taylor_ASORM = dG_du1_FORM'*U1 + 1/2*U1'*hess_G*U1;
    g3 = ezplot(Taylor_ASORM,ax);
    XY3 = get(g3,'contourMatrix');

    Hess_G = hessian(G);
    Hess_SORM = subs(subs(Hess_G,u1,U(1)),u2,U(2));
    % Hess_SORM = sormresults.hess_G;

    Taylor_SORM = dG_du1_FORM'*U1 + 1/2*U1'*Hess_SORM*U1;
    g2 = ezplot(Taylor_SORM,ax);
    XY2 = get(g2,'contourMatrix');




    %%plot
    ezplot(G,ax)
    setcurve('color','black','linewidth',2)
    hold on



    % axis(ax)
    axis square
    nxy2 = size(XY2,2);
    for i = 1:nxy2/16
        j = 16*i;
    %     new_XY3(:,i) = XY3(:,j);
        new_XY2(:,i) = XY2(:,j);
    end
    nxy3 = size(XY3,2);

    for i = 1:nxy3/16
        j = 16*i;
        new_XY3(:,i) = XY3(:,j);
    %     new_XY2(:,i) = XY2(:,j);
    end

    plot(new_XY2(1,1:end),new_XY2(2,1:end))
    setcurve('color','red','linestyle','o','linewidth',1)
    plot(new_XY3(1,1:end),new_XY3(2,1:end))
    setcurve('color','red','linestyle','*','linewidth',1)
    plot(XY1(1,2:end),XY1(2,2:end))
    setcurve('color','blue','linestyle','--','linewidth',1)
    legend('G(u)=0','SORM line','ASORM line','FORM line')
    plot(U(1),U(2),'.')
    setcurve('MarkerSize',25)
    hold off
end
%% GX2D_SORM
Hess_G = -sormresults.hess_G ;
alpha = -formresults.alpha;
norm_Grad_G = norm(formresults.grad_g(:,end));
beta = formresults.beta1;


nrv = 2;
% gfundata(1).expression = '-0.137567953228048 -0.796287767694799*x(1) -0.796287767694985*x(2) -0.551737974728446*x(1)^2  +2*0.064436223723041*x(1)*x(2) -0.551737974728446*x(2)^2 ';

a = -beta + beta^2/2*alpha'*Hess_G/norm_Grad_G*alpha;

b = -(-alpha'+beta*alpha'*Hess_G/norm_Grad_G)';

C = 1/2*Hess_G/norm_Grad_G;

a = -a;
b = -b;
C = -C;

mu = [0 0];
sigma = [1 1];

[bb cc mu_y sig_y] = make_complete_squared(b,C,mu,sigma,nrv);

[lb n nc r sigma c]=tt_gchi(nrv,a,bb,cc,mu_y,sig_y);

lim = 10^6;
acc = 10^(-5);

[qf_sorm trace] = qfc(lb,nc,n,r,sigma,c,lim,acc);
qf_sorm
%% GX2D_ASORM
Hess_G = -sormresults_ASORM.hess_G ;
alpha = formresults.alpha;
norm_Grad_G = norm(formresults.grad_g(:,end));
beta = formresults.beta1;


nrv = 2;
% gfundata(1).expression = '-0.137567953228048 -0.796287767694799*x(1) -0.796287767694985*x(2) -0.551737974728446*x(1)^2  +2*0.064436223723041*x(1)*x(2) -0.551737974728446*x(2)^2 ';

a = -beta + beta^2/2*alpha'*Hess_G/norm_Grad_G*alpha;

b = -(-alpha'+beta*alpha'*Hess_G/norm_Grad_G)';

C = 1/2*Hess_G/norm_Grad_G;

a = -a;
b = -b;
C = -C;

mu = [0 0];
sigma = [1 1];

[bb cc mu_y sig_y] = make_complete_squared(b,C,mu,sigma,nrv);

[lb n nc r sigma c]=tt_gchi(nrv,a,bb,cc,mu_y,sig_y);

lim = 10^6;
acc = 10^(-5);

[qf_asorm trace] = qfc(lb,nc,n,r,sigma,c,lim,acc);
qf_asorm

% kappa
% analy_kappa
%% feasibility check by MCS
if Flag_MCS == 1
    totaln = 1E07;
    nf1 = 0;
    ndv = 2;
    parfor i = 1 : totaln
        X = Aver_X + Sig_X .* randn(ndv,1);

        G1 = -(exp(0.8*X(1)-1.2) + exp(0.7*X(2) - 0.6) - 5)/10;

        if G1 <= 0
            nf1 = nf1 + 1;    
        end


    end
    pf = nf1 / totaln
end


save Normal_Data.dat formresults;
save Normal_Data.dat sormresults -append;
save Normal_Data.dat sormresults_ASORM -append;
save Normal_Data.dat qf_sorm -append;
save Normal_Data.dat qf_asorm -append;
% save Normal_Data.dat pf -append;

