function [G_value Grad_G_rt_X  U Iter_constraint history VBeta]=SubProblem(DMPFP_U,Aver_X,Sig_X,Distri,Index_G,Beta_input,VBeta,ndv,Iter_constraint,history)


Epislion = 0.0001;
No_Intp =5;
Delta_min = 1e-6;
Delta_ratio = 0.0005;
Iter = 0;
Sign = 1;


U = DMPFP_U(:,Index_G);
[G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X, Distri,Index_G,U,Iter_constraint);



Grad_G_prev = zeros(ndv,3);
U_prev = zeros(ndv,3);
G_prev = zeros(1,3);

while 1
    
    [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X,Distri, Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);    
    
    U_prev = [U_prev(:,2) U_prev(:,3) U];
    G_prev = [G_prev(2) G_prev(3) G];
    Grad_G_prev = [Grad_G_prev(:,2) Grad_G_prev(:,3) Grad_G];
    
    if norm(U) <= 1E-15 
        norm_U = 1E-15;
    else
        norm_U = norm(U);
    end
    if norm(Grad_G) <= 1E-15
        norm_Grad_G = 1E-15;
    else
        norm_Grad_G = norm(Grad_G);
    end
    
    KKT_Cond = abs( Sign*U'/norm_U * (-Grad_G)/norm_Grad_G -1 );
    
    if KKT_Cond <= Epislion && Iter >= 2          
%     if KKT_Cond <= Epislion    
        break
    end
%     if Iter > 1
%         if abs((G_old - G)/G_old) <= Epislion && Iter >= 2 
%             break
%         end
%     end
    
    
    if Iter >= 100
        disp('Fail to find iMPP')
    end
    
    if Iter >= 2 && Sign*(G_prev(3) - G_prev(2)) > 0 
        % Arc Interpolation 
        [U  Iter_constraint U_prev  Grad_G_prev]= Arc_Interpolation(Index_G,  VBeta,  U, G, Iter,  Grad_G, Iter_constraint, G_prev, U_prev , Grad_G_prev);
    else
        % HMV
        [U  Iter_constraint U_prev  Grad_G_prev]= HMV(Index_G,  VBeta,  U, Iter,  Grad_G, Iter_constraint,U_prev , Grad_G_prev);
    end
        
    G_old = G;
    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X, Distri,Index_G,U,Iter_constraint);
    
    Iter = Iter + 1;        
end
[VBeta Iter_constraint]= Calculate_VBeta_DRM(Aver_X,Sig_X,Distri,Index_G,Beta_input,VBeta,Grad_G,U,G, No_Intp,ndv,Iter_constraint);

U = VBeta(Index_G)*U/norm(U);

[G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);

[Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);

G_value = G;

% Calculation of Jacobian
[X J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);

Grad_G_rt_X = J_u_x*Grad_G;
end

function [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint)

Delta = zeros(ndv,1);
for i = 1:ndv
    Delta(i) = abs(U(i)) * Delta_ratio;
    if Delta(i) <= Delta_min 
        Delta(i) = Delta_min;
    end
end

U_plus_del = U;
Grad_G = zeros(ndv,1);
for i = 1:ndv
    U_plus_del(i) = U(i) + Delta(i);
    
    [G_forward Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X, Distri,Index_G,U_plus_del,Iter_constraint);
    
    Grad_G(i) = (G_forward - G) / Delta(i);
    
    U_plus_del(i) = U(i);    
end   

end


function [U  Iter_constraint U_prev  Grad_G_prev]= HMV(Index_G,  VBeta,  U, Iter,  Grad_G, Iter_constraint,  U_prev , Grad_G_prev)

Grad_G_k = Grad_G;
Grad_G_k_1 = Grad_G_prev(:,2);
Grad_G_k_2 = Grad_G_prev(:,1);

if norm(Grad_G_k) <= 1E-15
    n_k = -Grad_G_k/1E-15;
else
    n_k = -Grad_G_k/norm(Grad_G_k);
end
if norm(Grad_G_k_1) <= 1E-15
    n_k_1 = -Grad_G_k_1/1E-15;
else
    n_k_1 = -Grad_G_k_1/norm(Grad_G_k_1);
end
if norm(Grad_G_k_2) <= 1E-15
    n_k_2 = -Grad_G_k_2/1E-15;
else
    n_k_2 = -Grad_G_k_2/norm(Grad_G_k_2);
end

if Iter == 0
    F_switch = 0; 
elseif Iter == 1
    F_switch = 0; 
else
    Zeta = (n_k - n_k_1)'*(n_k_1 - n_k_2);
    if Zeta >= 0
        F_switch = 0; % 0 -> convex
    else 
        F_switch = 1; % 1 -> concave
    end
end


if F_switch == 1
% concave -> CMV
    G_normal = n_k + n_k_1 + n_k_2;
    Dnorm_G = sqrt(G_normal'*G_normal);
    
    if Dnorm_G <= 1e-15
        Dnorm_G = 1e-15;
    end
    
    G_normal = G_normal/Dnorm_G;
    U = VBeta(Index_G)*G_normal;
    
    
    
elseif F_switch == 0
% convex -> AMV    
    U = VBeta(Index_G)*n_k;
    
    
    
end
    
end

function [U  Iter_constraint U_prev  Grad_G_prev]= Arc_Interpolation(Index_G,  VBeta,  U, G, Iter,  Grad_G, Iter_constraint,G_prev, U_prev , Grad_G_prev)

G_old = G_prev(2);
U_old = U_prev(:,2);
Grad_G_old = Grad_G_prev(:,2);
Bt = VBeta(Index_G);

A0 = G_old;

U_dot = U'*U_old;
if abs(U_dot) <= 1E-15; U_dot = 1E-15; end

D_Gk_minus_1 = Grad_G_old'*(-U_dot/Bt^2*U_old + U);
% D_Gk = Grad_G_old'* ( - Bt^2/U_dot*U_old + U);
D_Gk = Grad_G'* ( - Bt^2/U_dot*U_old + U);
p1 = G_old;
p2 = G;
p3 = D_Gk_minus_1;
p4 = D_Gk;

a0 = p1;
a1 = p3;
a2 = -p4 -2*p3 +3*p2 -3*p1;
a3 = p4 + p3 -2*p2 +2*p1;

% A1 = D_Gk_minus_1;
% 
% AA = G - A0 - A1;
% BB = D_Gk - A1;
% A2 = 3*AA - BB;
% A3 = -2*AA + BB;

% obj = @(t) -(A0 + A1*t + A2*t^2 + A3*t^3);
obj = @(t) -(a0 + a1*t + a2*t^2 + a3*t^3);

[ts fval] = fminbnd(obj,0,1);
    
S = (-ts*U_old'*U + sqrt( (ts*U_old'*U)^2 + (1-ts^2)*Bt^4 ) ) / Bt^2;

U = S*U_old + ts*U;

end