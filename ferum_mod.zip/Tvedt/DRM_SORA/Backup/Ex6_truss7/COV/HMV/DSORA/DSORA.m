function [x,fval,exitflag,output,Shift_X,history] = DSORA(x0,ncon,lb,ub,Cov_X,Distri,Beta_input,VBeta, history, fid1)



myf = [];
myc = [];


ndv = size(x0,1);
epsi = 1E-04;
Iter_constraint = zeros(ncon,1);
Iter_obj = 0;



DMPFP_U = zeros(ndv+2,ncon);

Shift_X = zeros(ndv+2,ncon);

fun = @objfun;
cfun = @constr;

% options=optimset('Display','iter-detailed');
options=optimset('Display','iter-detailed','TolCon',epsi,'Tolfun',epsi,'TolX',epsi,'Algorithm','SQP');

%% first iteration k = 0
% [x,fval,exitflag,output]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,cfun,options);
% 
% fprintf(fid1,'\nx0: %f %f\n',x0(1),x0(2));
% fprintf(fid1,'shift_vector\n');
% fprintf(fid1,'%f %f %f\n',Shift_X(1,1),Shift_X(1,2),Shift_X(1,3));
% fprintf(fid1,'%f %f %f\n',Shift_X(2,1),Shift_X(2,2),Shift_X(2,3));
% fprintf(fid1,'x: %f %f, fval: %f\n',x(1),x(2),fval);

%% 

x= x0;

Del_obj = epsi*10;

Del_obj1 = Del_obj*10;

Obj_old = 10;

% Ctmin = 0.003;
U = zeros(ndv,1);
G_value_recorded = zeros(ncon,1);
Sum_FE_RA = 0;
while Del_obj1 >= Del_obj 
    Aver_X = [x;1500;1000];
    Sig_X = Aver_X.*Cov_X;
    Iter_constraint_old = Iter_constraint;
    for Index_G = 1:ncon

        [G_value U Iter_constraint history VBeta]=SubProblem(DMPFP_U,Aver_X,Sig_X,Distri,Index_G,Beta_input,VBeta, ndv,Iter_constraint,history,G_value_recorded);

%         DMPFP_X(:,Index_G) = Aver_X + U .* Sig_X;
        [DMPFP_X J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);
        
        DMPFP_U(:,Index_G) = U;
                
        Shift_X(:,Index_G) = Aver_X - DMPFP_X;
        
        G_value_recorded(Index_G) = G_value;
       
        
    end
    Iter_constraint_RA = Iter_constraint  - Iter_constraint_old;
    Sum_FE_RA = Sum_FE_RA + sum(Iter_constraint_RA);
    myf = [];
    myc = [];
    x0 = Aver_X(1:7);
    
    [x,fval,exitflag,output]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,cfun,options);

    
    Del_obj1 = abs((fval-Obj_old)/Obj_old);
    Del_obj2 = abs((fval-Obj_old));
    Del_obj1 = min([Del_obj1,Del_obj2]);

    Obj_old = fval;   
    
    fprintf(fid1,'\nx0: %f %f %f %f %f %f %f\n',x0);
%     fprintf(fid1,'shift_vector\n');
%     fprintf(fid1,'%f %f %f\n',Shift_X(1,1),Shift_X(1,2),Shift_X(1,3));
%     fprintf(fid1,'%f %f %f\n',Shift_X(2,1),Shift_X(2,2),Shift_X(2,3));
    fprintf(fid1,'x: %f %f %f %f %f %f %f, fval: %f\n',x,fval);
%     fprintf(fid1,'G_feasibility: %f %f %f\n',G_value_recorded);
    fprintf(fid1,'Iter_RA: %d %d %d %d %d %d %d\n',Iter_constraint_RA);
    
    
end

fprintf(fid1,'\nIteration constraints: %d %d %d %d %d %d %d\n',Iter_constraint);
fprintf(fid1,'total function call for reliability analysis: %d\n',Sum_FE_RA);
fprintf(fid1,'total_constraint: %d\n',sum(Iter_constraint));

fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%% Feasibility check
    pfs = zeros(ncon,1);
    bts = zeros(ncon,1);
    bts_f = zeros(ncon,1);
    j=0;
    Mu =[x;1500;1000];
    for i = 1:ncon
        j=j+1
        [Pf Beta] = Feasible_check(Mu,Cov_X,i,Distri);
        pfs(i) = Pf;
        bts(i) = -norminv(Pf);
        bts_f(i) = Beta;
    end
    pft = normcdf(-Beta_input(1));



    Err = (pft - pfs)/pft ;
    fprintf(fid1,'\nfeasible check\n');
    fprintf(fid1,'Pf: %f %f %f %f %f %f %f\n',pfs);
    fprintf(fid1,'err: %f %f %f %f %f %f %f\n',Err);
    fprintf(fid1,'Beta(FORM): %f %f %f %f %f %f %f\n',bts_f);
    fprintf(fid1,'Beta(IC): %f %f %f %f %f %f %f\n',bts);
%% Calculate objective and constraint functions
    function [y] = objfun(X)
         xn = [-150 0 0;-50 0 200;0 -50 0;50 0 200;0 50 0;150 0 0];
        elem = [1 2;2 3;2 5;3 4;4 5;2 4;4 6];
        myf = 0;
        for i = 1:7
            myf = myf + norm( xn(elem(i,1),:) - xn(elem(i,2),:) )*X(i) ;
        end           
        Iter_obj = Iter_obj + 1;

        y = myf;      

    end

    function [c,ceq] = constr(x)

        [myf,  myc, Iter_obj, Iter_constraint] = computeall(x,Iter_obj,Iter_constraint, Shift_X);

        c = myc;

        ceq = [];

    end

    
    
    
end

