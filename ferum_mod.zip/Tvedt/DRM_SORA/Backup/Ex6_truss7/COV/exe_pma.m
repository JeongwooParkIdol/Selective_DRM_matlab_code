%% ex9_55_truss
newFolder='E:\study\matlab\excersice\For_third_paper\Ex6_truss7\COV\FSORA';

cd(newFolder);

Main_FSORA


newFolder='E:\study\matlab\excersice\For_third_paper\Ex6_truss7\COV\FPMA';

cd(newFolder);

Main_FPMA

newFolder='E:\study\matlab\excersice\For_third_paper\Ex6_truss7\COV\DSORA';

cd(newFolder);

Main_DSORA

newFolder='E:\study\matlab\excersice\For_third_paper\Ex6_truss7\COV\DPMA';

cd(newFolder);

Main_DPMA
