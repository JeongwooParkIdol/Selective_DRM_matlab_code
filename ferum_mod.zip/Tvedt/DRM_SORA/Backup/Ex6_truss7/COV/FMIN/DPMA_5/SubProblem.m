function [G_value Grad_G_rt_X  U Iter_constraint history VBeta]=SubProblem(DMPFP_U,Aver_X,Sig_X,Index_G,Beta_input,VBeta,ndv,Distri,Iter_constraint,history)




No_Intp = 5;

Delta_min = 1e-10;
Delta_ratio = 0.0005;



U = DMPFP_U(:,Index_G);


if U == zeros(ndv,1)
    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);

    [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);    

    if norm(Grad_G) <= 1E-15
        n_k = -Grad_G/1E-15;
    else
        n_k = -Grad_G/norm(Grad_G);
    end

    U = VBeta(Index_G)*n_k;
end
x0 = U;

epsi = 1E-03;
rel_fun = @(u) Sub_eval(Aver_X,Sig_X,Distri,Index_G,u,Iter_constraint);
cfun = @(u) constr(u,VBeta,Index_G);
options=optimset('Display','none','TolCon',epsi,'Tolfun',epsi,'TolX',epsi,'Algorithm','SQP');

[U,fval,exitflag,output,lambda,grad]=fmincon(rel_fun , x0 ,[] ,[],[],[],[],[],cfun,options);

Iter_constraint(Index_G) = Iter_constraint(Index_G) + output.funcCount;


[VBeta Iter_constraint]= Calculate_VBeta_DRM(Aver_X,Sig_X,Distri,Index_G,Beta_input,VBeta,grad,U,fval, No_Intp,ndv,Iter_constraint);

U = VBeta(Index_G)*U/norm(U);

[G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);

[Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);

[x J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);
    
G_value = G;

Grad_G_rt_X = J_u_x*Grad_G;


function [c,ceq] = constr(U,VBeta,Index_G)
    c =[];
    ceq = norm(U) - VBeta(Index_G);
end

end
function [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint)

X = Aver_X + U.*Sig_X;


Delta = zeros(ndv,1);
for i = 1:ndv
    Delta(i) = abs(U(i)) * Delta_ratio;
    if Delta(i) <= Delta_min 
        Delta(i) = Delta_min;
    end
end

U_plus_del = U;
Grad_G = zeros(ndv,1);
for i = 1:ndv
    U_plus_del(i) = U(i) + Delta(i);

    [G_forward Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U_plus_del,Iter_constraint);
    
    Grad_G(i) = (G_forward - G) / Delta(i);
    
    U_plus_del(i) = U(i);    
end   

end

