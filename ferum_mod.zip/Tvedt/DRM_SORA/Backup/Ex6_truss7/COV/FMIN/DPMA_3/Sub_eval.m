function [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X, Distri,Index_G,U,Iter_constraint)

sum_U = U'*U;
Beta = sqrt(sum_U);
% for i = 1:size(U,1)
%     if Distri(i) == 1
%         X(i) = Aver_X(i) + U(i)*Sig_X(i);        
%     elseif Distri(i) == 11
%         Gum_alp = pi/(sqrt(6)*Sig_X(i));
%         Gum_nu = Aver_X(i) - 0.577216/Gum_alp;
%         X(i) = Gum_nu - 1/Gum_alp*log(-log(normcdf(U(i)) ));
% %     elseif Distri(i) ==2
% %         % for weibull distribution
% %         Wei_k = 24.949775176655670130789298428525;
% %         Wei_nu = 30E06/gamma(1+1/Wei_k);
% %         X(i) = Wei_nu*(-log( normcdf(-U(i)) ))^(1/Wei_k);
%     end
% end

[X J_u_x] = Transform_u_to_x(U,Aver_X,Sig_X,Distri);

% if Index_G == 1
%     G = X(1)^2 * X(2)/20 - 1;
% elseif Index_G == 2
%     G = (X(1) + X(2) - 5)^2/30 + (X(1) - X(2) -12)^2/120 - 1;
% elseif Index_G == 3
%     G = 80/(X(1)^2 + 8*X(2) + 5) - 1;
% end
[sigma] = truss_analysis_7_truss(X,Iter_constraint);
Iter_constraint(Index_G) = Iter_constraint(Index_G) + 1;
G = abs(sigma(Index_G)/2.5E04) - 1;
G = -G;

end