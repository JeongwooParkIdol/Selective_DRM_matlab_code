function [myc, Iter_constraint] = computeall(X,Iter_constraint)


sigma = truss_analysis_55_truss(X);
myc(1) = abs(sigma(1)/2.5E04) - 1;
Iter_constraint(1) = Iter_constraint(1) + 1;


sigma = truss_analysis_55_truss(X);
myc(2) = abs(sigma(2)/2.5E04) - 1;
Iter_constraint(2) = Iter_constraint(2) + 1;


sigma = truss_analysis_55_truss(X);
myc(3) = abs(sigma(3)/2.5E04) - 1;
Iter_constraint(3) = Iter_constraint(3) + 1;


sigma = truss_analysis_55_truss(X);
myc(4) = abs(sigma(4)/2.5E04) - 1;
Iter_constraint(4) = Iter_constraint(4) + 1;


sigma = truss_analysis_55_truss(X);
myc(5) = abs(sigma(5)/2.5E04) - 1;
Iter_constraint(5) = Iter_constraint(5) + 1;


sigma = truss_analysis_55_truss(X);
myc(6) = abs(sigma(6)/2.5E04) - 1;
Iter_constraint(6) = Iter_constraint(6) + 1;


sigma = truss_analysis_55_truss(X);
myc(7) = abs(sigma(7)/2.5E04) - 1;
Iter_constraint(7) = Iter_constraint(7) + 1;


end