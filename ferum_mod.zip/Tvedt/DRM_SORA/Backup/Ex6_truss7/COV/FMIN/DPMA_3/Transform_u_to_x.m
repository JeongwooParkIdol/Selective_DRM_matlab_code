function [x J_u_x] = Transform_u_to_x(u,Aver_X,Sig_X,Distri)


ndv = size(Aver_X,1);

for i = 1:ndv
    probdata.marg(i,:) =  [ Distri(i)  Aver_X(i)   Sig_X(i)  Aver_X(i)  0 0 0 0 0];
end


probdata.correlation = eye(ndv,ndv);

probdata.parameter = distribution_parameter(probdata.marg);


marg      = probdata.marg;
R         = probdata.correlation;


% Determine number of random variables
marg_dim = size(marg,1);

% Compute corrected correlation coefficients
Ro = mod_corr( probdata, R );


% Cholesky decomposition
Lo = (chol(Ro))';
iLo = inv(Lo);


x = u_to_x(u,probdata,Lo);



J_u_x = jacobian(x,u,probdata,Lo,iLo);

end