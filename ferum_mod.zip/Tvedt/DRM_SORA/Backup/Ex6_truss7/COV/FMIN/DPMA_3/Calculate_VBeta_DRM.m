function [VBeta Iter_constraint]= Calculate_VBeta_DRM(Aver_X,Sig_X,Distri, Index_G,Beta_input,VBeta,Grad_G,U,G, No_Intp,ndv,Iter_constraint)
    



beta = VBeta(Index_G);

%    Compute the rotation matrix
alpha = U/norm(U);

R = gram_schmidt(alpha');
iR = inv(R);

% Three Integration point
if No_Intp == 3
    % Quadrature point and weight
    Qp = [-sqrt(3) sqrt(3) 0 ];
    Wf = [1/6 1/6 4/6];
    
    b1 = norm(Grad_G);
    if b1 <= 1E-15;        b1 = 1E-15;    end
    
    Pf_drm = 1;
    for i = 1:ndv-1
        sum_j = 0;
        for j = 1:2
            % Integration point
            V_int = zeros(ndv,1);
            V_int(end) = beta;
            V_int(i) = Qp(j);
            U_int = iR*V_int;
            
%             [G_int Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Index_G,U_int,Iter_constraint);
            [G_int Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U_int,Iter_constraint);
            
            G_int = G_int - G;
            sub_int = - beta - G_int/b1;
            
            sum_j = sum_j + Wf(j)*normcdf(sub_int);              
        end
        sub_int = - beta - 0/b1;
        sum_j = sum_j + Wf(end)*normcdf(sub_int);  
        Pf_drm = Pf_drm * sum_j;
    end
    Pf_drm = Pf_drm/normcdf(-beta)^(ndv-2);
elseif No_Intp == 5
    % Quadrature point and weight
    Qp = [-2.856970013873 -1.355626179974 1.355626179974  2.856970013873 0 ];
    Wf = [0.01125741132772 0.2220759220056 0.2220759220056 0.01125741132772 0.53333333333333333];
    
    b1 = norm(Grad_G);
    if b1 <= 1E-15;        b1 = 1E-15;    end
    
    Pf_drm = 1;
    for i = 1:ndv-1
        sum_j = 0;
        for j = 1:4
            % Integration point
%             G_int = 0;
            V_int = zeros(ndv,1);
            V_int(end) = beta;
            V_int(i) = Qp(j);
            U_int = iR*V_int;
            
            [G_int Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U_int,Iter_constraint);
            G_int = G_int - G;
            
            sub_int = - beta - G_int/b1;
            
            sum_j = sum_j + Wf(j)*normcdf(sub_int);           
        end
        sub_int = - beta - 0/b1;
        sum_j = sum_j + Wf(end)*normcdf(sub_int);  
        Pf_drm = Pf_drm * sum_j;
    end
    Pf_drm = Pf_drm/normcdf(-beta)^(ndv-2);  
    
end
            
        


Modified_beta =- norminv( Pf_drm);



VBeta(Index_G) = VBeta(Index_G) - (Modified_beta - Beta_input(Index_G) );

    
    
end







