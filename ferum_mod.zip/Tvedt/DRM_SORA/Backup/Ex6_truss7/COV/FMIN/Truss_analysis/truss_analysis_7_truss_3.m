function myc = truss_analysis_7_truss_3(x)
Iter_constraint = 1;
[sigma] = truss_analysis_7_truss(x,Iter_constraint);

c = abs(sigma(3)/2.5E04) - 1;
myc = -c;


end