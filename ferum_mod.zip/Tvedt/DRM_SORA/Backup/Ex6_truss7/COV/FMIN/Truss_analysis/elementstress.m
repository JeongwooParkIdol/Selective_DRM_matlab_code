function [sigma] = elementstress(E,ndf,numel,elem,ug,x1,x2,x3)
sigma = zeros(numel,1);
for e = 1:numel
    eIndex = elem(e,:);
    xx = x1(eIndex(2)) - x1(eIndex(1));
    yy = x2(eIndex(2)) - x2(eIndex(1));
    zz = x3(eIndex(2)) - x3(eIndex(1));
    Length = sqrt(xx^2 +yy^2 + zz^2);
    
    l = xx/Length;
    m = yy/Length;
    n = zz/Length;
    
    B = [-1/Length 1/Length];
    Ts = [l m n 0 0 0;0 0 0 l m n];
    eDof = [eIndex(1)*ndf-2 eIndex(1)*ndf-1 eIndex(1)*ndf ...
        eIndex(2)*ndf-2 eIndex(2)*ndf-1 eIndex(2)*ndf];
    sigma(e) = E*B*Ts*ug(eDof);
end