function [s]=elementstiffness(EM,A,x1,x2,x3,eIndex,e)

xx = x1(eIndex(2)) - x1(eIndex(1));
yy = x2(eIndex(2)) - x2(eIndex(1));
zz = x3(eIndex(2)) - x3(eIndex(1));

Length = sqrt(xx^2 +yy^2 + zz^2);
k = EM*A(e)/Length;
l = xx/Length;
m = yy/Length;
n = zz/Length;
ll = l*l;mm =m*m; nn = n*n;
lm = l*m;ln = l*n;mn=m*n;

dc(1,1) = ll;dc(1,2)=lm;dc(1,3) = ln;
dc(2,1) = lm;dc(2,2)=mm;dc(2,3) = mn;
dc(3,1) = ln;dc(3,2)=mn;dc(3,3) = nn;

s(1,1) = ll; s(1,2) = lm; s(1,3) = ln; s(1,4) = -ll; s(1,5) = -lm; s(1,6) = -ln;
s(2,1) = lm; s(2,2) = mm; s(2,3) = mn; s(2,4) = -lm; s(2,5) = -mm; s(2,6) = -mn;
s(3,1) = ln; s(3,2) = mn; s(3,3) = nn; s(3,4) = -ln; s(3,5) = -mn; s(3,6) = -nn;
s(4,1) = -ll; s(4,2) = -lm; s(4,3) = -ln; s(4,4) = ll; s(4,5) = lm; s(4,6) = ln;
s(5,1) = -lm; s(5,2) = -mm; s(5,3) = -mn; s(5,4) = lm; s(5,5) = mm; s(5,6) = mn;
s(6,1) = -ln; s(6,2) = -mn; s(6,3) = -nn; s(6,4) = ln; s(6,5) = mn; s(6,6) = nn;

s = k*s;

end