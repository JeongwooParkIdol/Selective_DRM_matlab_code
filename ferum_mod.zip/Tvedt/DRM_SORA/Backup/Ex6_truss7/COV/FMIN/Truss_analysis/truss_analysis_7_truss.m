function [sigma] = truss_analysis_7_truss(X,Iter_constraint)
% FE control data
numel = 7; % number of element
numnp = 6; % number of node
ndf = 3; % number of degree of freedom
nst = numnp * ndf; % total degree of freedom of the structure
% material properties : all the members have the same length
E = 30E06;
% E = X(10);
% A = [0.02;0.02;0.02;0.02;0.02;0.02;0.02];
A = X(1:7);
% Iter_constraint = Iter_constraint +1;
% initialization of array
u = zeros(nst,1);
f = zeros(nst,1);
s = zeros(nst,nst);

% nodal coordinates
x = [-150 0 0;-50 0 200;0 -50 0;50 0 200;0 50 0;150 0 0];
x1 = x(:,1);
x2 = x(:,2);
x3 = x(:,3);
% element connectivities
elem = [1 2;2 3;2 5;3 4;4 5;2 4;4 6];
% structural stiffness I
s = stiffness(numnp,numel,ndf,elem,E,A,x1,x2,x3);
ebc = [1:3 7:9 13:18];
% natural boundary condition
% f(6) = -1500;
% f(12) = -1000;
f(6) = -X(8);
f(12) = -X(9);
% free degree of freedom
freeDof = setdiff([1:numnp*ndf]',ebc);
% displacement vector with only free degree of freedom
u = s(freeDof,freeDof)\f(freeDof);
% make the full size of displacement vector
ug = zeros(numnp*ndf,1);
ug(freeDof) = u;
% calculation the reation
f = s*ug;
% reaction = f(ebc);
% calculate the element stress 
sigma = elementstress(E,ndf,numel,elem,ug,x1,x2,x3);
end