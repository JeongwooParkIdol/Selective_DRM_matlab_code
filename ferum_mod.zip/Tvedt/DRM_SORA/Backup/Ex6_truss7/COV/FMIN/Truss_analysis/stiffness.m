function [s]=stiffness(numnp,numel,ndf,elem,EM,A,x1,x2,x3)

s = zeros(numnp*ndf,numnp*ndf);
for e=1:numel
    eIndex = elem(e,:);
    eDof = [eIndex(1)*ndf-2 eIndex(1)*ndf-1 eIndex(1)*ndf ...
        eIndex(2)*ndf-2 eIndex(2)*ndf-1 eIndex(2)*ndf];
    ks = elementstiffness(EM,A,x1,x2,x3,eIndex,e);
    s(eDof,eDof) = s(eDof,eDof) + ks;
end

end