function [pf bts] = MCS(ndv,ncon, Aver_X, Sig_X)
mu = Aver_X;
sigma = Sig_X;

nf1 = 0;
nf2 = 0;
nf3 = 0;
totaln = 1E07;


% matlabpool(4)

parfor i = 1 : totaln
    x = mu + sigma .* randn(ndv,1);
    gx1 = (x(1)^2 * x(2)/20 - 1);
    gx2 = 1 - (0.9063*x(1) + 0.4226*x(2) - 6)^2 -(0.9063*x(1) + 0.4226*x(2) - 6)^3 +0.6*(0.9063*x(1) + 0.4226*x(2) - 6)^4 + (-0.4226*x(1) + 0.9063*x(2));
    gx3 = 80/(x(1)^2 + 8*x(2) + 5) - 1;
    
    if gx1 <= 0
        nf1 = nf1 + 1;    
    end
    if gx2 <= 0
        nf2 = nf2 +1 ;
    end
    if gx3 <= 0
        nf3 = nf3 +1 ;
    end
    
end

% matlabpool close
nf = [nf1;nf2;nf3];
pf = nf / totaln; 
bts = -norminv(pf);