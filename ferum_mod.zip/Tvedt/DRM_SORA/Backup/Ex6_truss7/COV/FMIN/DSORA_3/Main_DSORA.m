clear all

addpath '../Truss_analysis'

% x0 = [0.035;0.035;0.035;0.035;0.035;0.035;0.035];
x0 = [0.017; 0.024; 0.024; 0.017; 0.017; 0.0100; 0.0100];
ncon = 7;

lb = [0.01;0.01;0.01;0.01;0.01;0.01;0.01];
ub = [0.05;0.05;0.05;0.05;0.05;0.05;0.05];


% Beta_input = [2 2 2 2 2 2 2 ];
Cov_X = [zeros(7,1)+0.1;0.05;0.05];
Distri(1:7) = 1;
Distri(8) = 11;
Distri(9) = 11;

Beta_input = [3 3 3 3 3 3 3];
VBeta= Beta_input;

history.x = [];
history.x1 = [];
history.x2 = [];
history.x3 = [];
history.x4 = [];
history.x5 = [];
history.x6 = [];
history.x7 = [];

history.fval = [];
history.gval = [];
history.gval1 = [];
history.gval2 = [];
history.gval3 = [];
history.gval4 = [];
history.gval5 = [];
history.gval6 = [];
history.gval7 = [];
history.gradc1 = [];
history.gradc2 = [];
history.gradc3 = [];
history.gradc4 = [];
history.gradc5 = [];
history.gradc6 = [];
history.gradc7 = [];


fid1 = fopen('DSORA.txt','w');
[x,fval,exitflag,output,Shift_X,history] = DSORA(x0,ncon,lb,ub,Cov_X,Distri,Beta_input, VBeta, history, fid1);

fclose(fid1);
