function [B B1] = make_Hessian(Grad_Total, X_Total)
        

n = size(Grad_Total,2);
ndv = size(Grad_Total,1);

n_grad = n;





B = zeros(ndv);
B1 =zeros(ndv);
B2 = zeros(ndv);
%         B = 1/lam1*eye(ndv);
%         for ii = 1:ncon
%             B = [B zeros(ndv)];
%             B1 = [B1 zeros(ndv)];          
%         end
iter = 1;
for ii = 1:n_grad-1            


    sk = X_Total(:,ii+1) - X_Total(:,ii);                
    yk = Grad_Total(:,ii+1) -Grad_Total(:,ii) ;
    rk = yk - B*sk;
    if iter == 0
        diag_B = yk./sk;
        B_temp = diag(diag_B);
    else
        if abs(rk'*sk) <= 1E-06*norm(sk)*norm(rk)
            B_temp = zeros(ndv);
            disp('sss');
        else
            B_temp = rk*rk'/(rk'*sk);
        end
    end


%                 B_temp = B2(:,ndv*j-1:ndv*j-1+(ndv-1)) + rk*rk'/(rk'*sk);
%                 B1_temp = B2(:,ndv*j-1:ndv*j-1+(ndv-1)) + (rk*sk'+sk*rk')/norm(sk)^2 - (rk'*sk)/norm(sk)^4*sk*sk';

    B = B + B_temp;

    B1 = B1 + (rk*sk'+sk*rk')/norm(sk)^2 - (rk'*sk)/norm(sk)^4*sk*sk';
    iter = 1;
%             B = B2;

end

% G1 = 1/2*(X_Total(:,end-1) - X_Total(:,end))'*B*(X_Total(:,end-1) - X_Total(:,end)) + Grad_Total(:,end)'*(X_Total(:,end-1)-X_Total(:,end));
% 
% G2 = 1/2*(X_Total(:,end-1) - X_Total(:,end))'*B1*(X_Total(:,end-1) - X_Total(:,end)) + Grad_Total(:,end)'*(X_Total(:,end-1)-X_Total(:,end));
%         if cond(B) > cond(B1)
%             B = B1;
%         end

%         x1 = history.x(1,end);
%         x2 = history.x(2,end);               
%         
%         B2 = [(8*exp((4*x1)/5-6/5))/125 0;0 (49*exp((7*x2)/10-3/5))/1000];


% m = [0.01 0.3 360 226*10^(-6) 0.5 0.12 40];
% s = [0.003 0.015 36 1.1300e-05 0.05 0.006 6];
% syms u1 u2 u3 u4 u5 u6 u7
% x1 = u1*s(1)+m(1);
% x2 = u2*s(2)+m(2);
% x3 = u3*s(3)+m(3);
% x4 = u4*s(4)+m(4);
% x5 = u5*s(5)+m(5);
% x6 = u6*s(6)+m(6);
% x7 = u7*s(7)+m(7);
% retval = x2*x3*x4 - x5*x3^2*x4^2/(x6*x7)- x1;
% B2 = hessian(retval,[u1 u2 u3 u4 u5 u6 u7]);
% B2 = subs(subs(subs(subs(subs(subs(subs(B2,u1,U(1)),u2,U(2)),u3,U(3)),u4,U(4)),u5,U(5)),u6,U(6)),u7,U(7));
%          
        save hessian.dat B;
        save hessian.dat B1 -append;
        
end