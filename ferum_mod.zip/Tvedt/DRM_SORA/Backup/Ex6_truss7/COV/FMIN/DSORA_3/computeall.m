function [myf, myc,Iter_obj, Iter_constraint] = computeall(X,Iter_obj,Iter_constraint, Shift_X)

 xn = [-150 0 0;-50 0 200;0 -50 0;50 0 200;0 50 0;150 0 0];
elem = [1 2;2 3;2 5;3 4;4 5;2 4;4 6];
myf = 0;
for i = 1:7
    myf = myf + norm( xn(elem(i,1),:) - xn(elem(i,2),:) )*X(i) ;
end           

% grad_myf = [1, 1];
% Iter_obj = Iter_obj + 1;
% Iter_obj = Iter_obj + 2;


X= [X; 1500; 1000];


for i = 1:7
    X_s = X -  Shift_X(:,i);
    [sigma] = truss_analysis_7_truss(X_s);
    myc(i) = abs(sigma(i)/2.5E04) - 1;
    Iter_constraint(i) = Iter_constraint(i) + 1;
    
    
end


end