function [G_value U  Iter_constraint history]=SubProblem(DMPFP_U,Aver_X,Sig_X,Distri,Index_G,Beta_input,ndv,Iter_constraint,history)

Delta_min = 1e-10;
Delta_ratio = 0.005;


U = DMPFP_U(:,Index_G);


if U == zeros(ndv,1)
    [G Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U,Iter_constraint);

    [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint);    

    if norm(Grad_G) <= 1E-15
        n_k = -Grad_G/1E-15;
    else
        n_k = -Grad_G/norm(Grad_G);
    end

    U = Beta_input(Index_G)*n_k;
end
x0 = U;

epsi = 1E-03;
rel_fun = @(u) Sub_eval(Aver_X,Sig_X,Distri,Index_G,u,Iter_constraint);
cfun = @(u) constr(u,Beta_input);
options=optimset('Display','none','TolCon',epsi,'Tolfun',epsi,'TolX',epsi,'Algorithm','SQP');

[U,fval,exitflag,output,lambda,grad]=fmincon(rel_fun , x0 ,[] ,[],[],[],[],[],cfun,options);

Iter_constraint(Index_G) = Iter_constraint(Index_G) + output.funcCount;

function [c,ceq] = constr(U,Beta_input)
    c =[];
    ceq = norm(U) - Beta_input;
end



G_value = fval;

end


function [Iter_constraint Grad_G]= Gradient_G(Index_G, Aver_X, Sig_X, Distri,Delta_min, Delta_ratio, ndv, U, G, Iter_constraint)

X = Aver_X + U.*Sig_X;


Delta = zeros(ndv,1);
for i = 1:ndv
    Delta(i) = abs(U(i)) * Delta_ratio;
    if Delta(i) <= Delta_min 
        Delta(i) = Delta_min;
    end
end

U_plus_del = U;
Grad_G = zeros(ndv,1);
for i = 1:ndv
    U_plus_del(i) = U(i) + Delta(i);

    [G_forward Beta Iter_constraint] = Sub_eval(Aver_X,Sig_X,Distri,Index_G,U_plus_del,Iter_constraint);
    
    Grad_G(i) = (G_forward - G) / Delta(i);
    
    U_plus_del(i) = U(i);    
end   

end