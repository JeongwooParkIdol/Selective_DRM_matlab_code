% PMA - version 02
% analytical sensitivity analysis 
clear all
warning off;

addpath '../Truss_analysis'

x0 = [0.035;0.035;0.035;0.035;0.035;0.035;0.035];
ncon = 7;

lb = [0.01;0.01;0.01;0.01;0.01;0.01;0.01];
ub = [0.05;0.05;0.05;0.05;0.05;0.05;0.05];

Beta_input = [3 3 3 3 3 3 3];
% Beta_input = [2 2 2 2 2 2 2 ];
Sig_X = [zeros(7,1)+0.002;75/2;50/2];
% Sig_X = [zeros(7,1)+0.0030;75/2;50/2];
Distri(1:7) = 1;
Distri(8) = 11;
Distri(9) = 11;

history.x = [];
history.x1 = [];
history.x2 = [];
history.x3 = [];
history.x4 = [];
history.x5 = [];
history.x6 = [];
history.x7 = [];

history.fval = [];
history.gval = [];
history.gval1 = [];
history.gval2 = [];
history.gval3 = [];
history.gval4 = [];
history.gval5 = [];
history.gval6 = [];
history.gval7 = [];
history.gradc1 = [];
history.gradc2 = [];
history.gradc3 = [];
history.gradc4 = [];
history.gradc5 = [];
history.gradc6 = [];
history.gradc7 = [];


fid1 = fopen('FPMA.txt','w');
Flag_IC = 1;
[x,fval,exitflag,output,history] = FPMA(x0,lb,ub,Sig_X,Distri,Beta_input,history,ncon,fid1,Flag_IC);

fclose(fid1);