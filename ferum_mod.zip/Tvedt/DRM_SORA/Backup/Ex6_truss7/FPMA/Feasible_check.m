function [Pf Beta]= Feasible_check(mu,sigma,Index_G,Distri)

ndv = size(mu,1);
for i = 1:ndv
    probdata.marg(i,:) =  [ Distri(i)  mu(i)   sigma(i)  mu(i)  0 0 0 0 0];
end


 

probdata.correlation = eye(ndv,ndv);

probdata.parameter = distribution_parameter(probdata.marg);
gfundata(1).evaluator = 'basic';
gfundata(1).type = 'expression'; 
gfundata(1).parameter = 'no';

% FORM analysis options
analysisopt.ig_max    = 100;
analysisopt.il_max    = 5;
analysisopt.i_max = 100; % Maximum number of iterations allowed in the search algorithm
analysisopt.e1 = 0.001; % Tolerance on how close design point is to limit-state surface
analysisopt.e2 = 0.001; % Tolerance on how accurately the gradient points towards
                        % the origin
analysisopt.step_code = 0; % 0: step size by Armijo rule
                            % otherwise: given value is the step size
analysisopt.Recorded_u = 1; % 0: u-vector not recorded at all iterations
                            % 1: u-vector recorded at all iterations
analysisopt.Recorded_x = 1; % 0: x-vector not recorded at all iterations
                            % 1: x-vector recorded at all iterations
analysisopt.grad_flag = 'ffd';
analysisopt.ffdpara = 1000;

% IC analysis options
analysisopt.rand_generator = 1; % 0: default rand matlab function
                                % 1: Mersenne Twister (to be preferred)
analysisopt.num_sim = 1e7; % Number of samples

analysisopt.stdv_sim  = 1;

analysisopt.target_cov = 0.01;
analysisopt.lowRAM = 0; % 1: memory savings allowed
                        % 0: no memory savings allowed

femodel = 0;
randomfield.mesh = 0;

% performance function

% IC : dspt, CMCS : origin
analysisopt.sim_point = 'dspt';
% the nubmer of sampling points
% analysisopt.num_sim   = 1e04;


gfundata(1).expression = ['truss_analysis_7_truss_',num2str(Index_G),'(x)'];



    
[formresults] = form(1,probdata,analysisopt,gfundata,femodel,randomfield);
% analysisopt.sim_point = (DMPFP_X(:,Index_G)- mu)./sigma;
% analysisopt.sim_point = DMPFP_U(:,Index_G);

analysisopt.sim_point = formresults.dsptu;
% [simulationresults] = simulation(1,probdata,analysisopt,gfundata,femodel,randomfield);

% Pf= simulationresults.pf;
% 
sormresults = sorm_curvature_fitting(1,formresults,probdata,analysisopt,gfundata,femodel,randomfield);

Pf = sormresults.pf2;

Beta = formresults.beta1;
    
end
    