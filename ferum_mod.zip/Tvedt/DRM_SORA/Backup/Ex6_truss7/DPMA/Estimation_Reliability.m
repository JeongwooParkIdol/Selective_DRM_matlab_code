function [myc, grad_myc,  Iter_obj, Iter_constraint,history,DMPFP_U,VBeta] = Estimation_Reliability(x,Iter_obj,Iter_constraint,ncon,Sig_X,Distri,Beta_input,VBeta, history,DMPFP_U,fid1)



Aver_X = [x;1500;1000];
ndv = size(Aver_X,1);


Iter_old = zeros(ncon,1);


for Index_G = 1:ncon
    
   

    Iter_old(Index_G) = Iter_constraint(Index_G);
    [G_value Grad_G_rt_X  U Iter_constraint history VBeta]=SubProblem(DMPFP_U,Aver_X,Sig_X,Distri,Index_G,Beta_input,VBeta, ndv,Iter_constraint,history);
    
    Iter_old(Index_G) = Iter_constraint(Index_G) - Iter_old(Index_G);
    
    DMPFP_U(:,Index_G) = U;
    
    myc(Index_G) = -G_value; 

    grad_myc(Index_G,:) = -Grad_G_rt_X';
    
end
fprintf(fid1,'\nIteration constraints: %d %d %d %d %d %d %d\n',Iter_old);

    
end
    