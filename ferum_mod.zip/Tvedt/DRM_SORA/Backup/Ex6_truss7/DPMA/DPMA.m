function [x,fval,exitflag,output,history] = DPMA(x0,lb,ub,Sig_X,Distri,Beta_input,VBeta,history,ncon,fid1,Flag_IC)


xLast = [];
myf = [];
myc = [];
grad_myc = [];

ndv = size(x0,1);

% DMPFP_X= zeros(ndv+2,ncon);
% DDMPFP_X = zeros(ndv+2,ncon);
% 
% for i = 1:ncon
%     DDMPFP_X(:,i) = [x0;-1500;-1000];
% end

DMPFP_U= zeros(ndv+2,ncon);

Iter_constraint = zeros(ncon,1);
Iter_obj = 0;




fun = @objfun;
cfun = @constr;



epsi = 1E-04;
% options=optimset('Display','iter-detailed','TolCon',0.001,'Tolfun',0.001,'TolX',0.001,,'Algorithm','SQP');
% options=optimset('Display','iter-detailed','TolCon',epsi,'Tolfun',epsi,'TolX',epsi);

%% first iteration k = 0
% [x,fval,exitflag,output]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,cfun,options);
% 
% fprintf(fid1,'\nx0: %f %f %f %f %f %f %f\n',x0);
% % fprintf(fid1,'shift_vector\n');
% % fprintf(fid1,'%f %f %f\n',Shift_X(1,1),Shift_X(1,2),Shift_X(1,3));
% % fprintf(fid1,'%f %f %f\n',Shift_X(2,1),Shift_X(2,2),Shift_X(2,3));
% fprintf(fid1,'x: %f %f %f %f %f %f %f, fval: %f\n',x,fval);
% x0 = x;

%% PMA
options=optimset('Display','iter-detailed','TolCon',epsi,'Tolfun',epsi,'TolX',epsi,'GradConstr','on','Algorithm','SQP');
rel_cfun = @rel_constr;


xLast = [];
myf = [];
myc = [];


[x,fval,exitflag,output]=fmincon(fun , x0 ,[] ,[],[],[],lb,ub,rel_cfun,options);

fprintf(fid1,'x: %f %f %f %f %f %f %f, fval: %f\n',x,fval);
fprintf(fid1,'\nIteration constraints: %d %d %d %d %d %d %d\n',Iter_constraint);
fprintf(fid1,'total_constraint: %d\n',sum(Iter_constraint));
fprintf(fid1,'Iteration objective:%d\n',Iter_obj);

%% Feasible check
if Flag_IC == 1
    pfs = zeros(ncon,1);
    bts = zeros(ncon,1);
    bts_f = zeros(ncon,1);
    j=0;
    Mu = [x ; 1500; 1000];
    for i = 1:ncon
        j=j+1
        [Pf Beta] = Feasible_check(Mu,Sig_X,i,Distri);
        pfs(i) = Pf;
        bts(i) = -norminv(Pf);
        bts_f(i) = Beta;
    end
    pft = normcdf(-Beta_input(1));



    Err = (pft - pfs)/pft ;
    fprintf(fid1,'\nfeasible check\n');
    fprintf(fid1,'Pf: %f %f %f %f %f %f %f\n',pfs);
    fprintf(fid1,'err: %f %f %f %f %f %f %f\n',Err);
    fprintf(fid1,'Beta(FORM): %f %f %f %f %f %f %f\n',bts_f);
    fprintf(fid1,'Beta(IC): %f %f %f %f %f %f %f\n',bts);
end
%% Calculate objective and constraint functions


    function [y ] = objfun(X)
         xn = [-150 0 0;-50 0 200;0 -50 0;50 0 200;0 50 0;150 0 0];
        elem = [1 2;2 3;2 5;3 4;4 5;2 4;4 6];
        myf = 0;
        for i = 1:7
            myf = myf + norm( xn(elem(i,1),:) - xn(elem(i,2),:) )*X(i) ;
        end           
        Iter_obj = Iter_obj + 1;
        y = myf; 
    end

    function [c,ceq,gradc,gradceq] = rel_constr(x)
        if ~isequal(x,xLast)
            [myc, grad_myc,Iter_obj, Iter_constraint,history,DMPFP_U, VBeta] = Estimation_Reliability(x,Iter_obj,Iter_constraint,ncon,Sig_X,Distri,Beta_input,VBeta, history,DMPFP_U,fid1);
            xLast = x;
        end
        
        c = myc;
        if nargout > 2
            gradc = grad_myc(:,1:7)';
        end
        ceq = [];
        gradceq = [];

    end

    function [c,ceq] = constr(x)
        X = [x;-1500;-1000];
        [myc, Iter_constraint] = computeall(X,Iter_constraint);
        
        c = myc;

        ceq = [];

    end


end